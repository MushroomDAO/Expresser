// Expresser — variants showcase + tweaks (v2 with content pool)

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "primaryColor": "#e87aa3",
  "buttonVariant": "petal",
  "dark": false,
  "waveStyle": "bars",
  "windowMin": 30
}/*EDITMODE-END*/;

const { ExpresserApp, STATES } = window;
const { AndroidDevice, IOSDevice } = window;
const { DesignCanvas, DCSection, DCArtboard } = window;
const {
  TweaksPanel, useTweaks,
  TweakSection, TweakRadio, TweakColor, TweakToggle, TweakSelect, TweakSlider,
} = window;

function Phone({ variant, color, dark, waveStyle, forceState, windowMin, ios, large }) {
  const W = large ? 392 : 360;
  const H = large ? 800 : 740;
  const Frame = ios ? IOSDevice : AndroidDevice;
  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 9 }}>
      <Frame width={W} height={H} dark={dark}>
        <ExpresserApp
          variant={variant} color={color} dark={dark}
          waveStyle={waveStyle} forceState={forceState}
          windowMin={windowMin}
          compact={!!forceState && forceState !== STATES.IDLE} />
      </Frame>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const { primaryColor, buttonVariant, dark, waveStyle, windowMin } = t;

  const W = 378, H = 758;
  const Wlg = 410, Hlg = 818;

  return (
    <>
      <DesignCanvas>
        <DCSection
          id="hero"
          title="Expresser"
          subtitle="一颗花瓣按钮 → 一段语音/一张照片/一段视频 → 全进 30 分钟内容池 → 自动汇成草稿 → 5 秒内可拦截手挑片段。Android 主, iOS 适度。真的可以按住、上滑、切换。"
        >
          <DCArtboard id="live-android" label="A · 主交互 (Android, 完全可交互)" width={Wlg} height={Hlg}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={null} large />
          </DCArtboard>
          <DCArtboard id="live-ios" label="A2 · iOS 适配" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={null} ios />
          </DCArtboard>
        </DCSection>

        <DCSection
          id="flow"
          title="新流程 — 内容池模型"
          subtitle="片段不再每次都直接发布,而是先进入今天的池子,满 30 分钟自动汇成草稿,发前 5 秒可拦下来挑片段。"
        >
          <DCArtboard id="f-pool" label="01 · 加入内容池" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.POOL} />
          </DCArtboard>
          <DCArtboard id="f-ctd" label="02 · 5 秒倒计时拦截" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.COUNTDOWN} />
          </DCArtboard>
          <DCArtboard id="f-compose" label="03 · 手动挑选片段" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.COMPOSE} />
          </DCArtboard>
          <DCArtboard id="f-pub" label="04 · 自动发布" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.PUBLISHED} />
          </DCArtboard>
        </DCSection>

        <DCSection
          id="states"
          title="完整状态"
          subtitle="按住录音 → 上滑切相机 → 拍照/录像 → 全进池子 → 草稿 → 处理 → 同步 → 发布。每帧都是实时渲染,不是图。"
        >
          <DCArtboard id="s-idle" label="01 · Idle" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.IDLE} />
          </DCArtboard>
          <DCArtboard id="s-rec" label="02 · 按住录音" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.RECORDING} />
          </DCArtboard>
          <DCArtboard id="s-cam" label="03 · 相机" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.CAMERA} />
          </DCArtboard>
          <DCArtboard id="s-vid" label="04 · 长按录像" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.RECORDING_V} />
          </DCArtboard>
          <DCArtboard id="s-proc" label="05 · 本地拼版" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.PROCESSING} />
          </DCArtboard>
          <DCArtboard id="s-up" label="06 · 同步 NAS" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.UPLOADING} />
          </DCArtboard>
          <DCArtboard id="s-off" label="07 · 离线队列" width={W} height={H}>
            <Phone variant={buttonVariant} color={primaryColor} dark={dark} waveStyle={waveStyle} windowMin={windowMin} forceState={STATES.OFFLINE} />
          </DCArtboard>
        </DCSection>

        <DCSection
          id="variants"
          title="按钮风格变体"
          subtitle="花瓣 (默认) · 七彩 · Plasma · Glass。在 Tweaks 改可同步到主交互区。"
        >
          <DCArtboard id="v-petal" label="B1 · 花瓣 Petal (默认)" width={W} height={H}>
            <Phone variant="petal" color="#e87aa3" dark={false} waveStyle="bars" windowMin={30} forceState={STATES.IDLE} />
          </DCArtboard>
          <DCArtboard id="v-rainbow" label="B2 · 七彩 Conic" width={W} height={H}>
            <Phone variant="rainbow" color="#e87aa3" dark={false} waveStyle="bars" windowMin={30} forceState={STATES.IDLE} />
          </DCArtboard>
          <DCArtboard id="v-siri" label="B3 · 等离子" width={W} height={H}>
            <Phone variant="siri" color="#5ec5ff" dark={true} waveStyle="ribbon" windowMin={30} forceState={STATES.IDLE} />
          </DCArtboard>
          <DCArtboard id="v-glass" label="B4 · 玻璃" width={W} height={H}>
            <Phone variant="glass" color="#3fa57d" dark={false} waveStyle="dots" windowMin={30} forceState={STATES.IDLE} />
          </DCArtboard>
        </DCSection>

        <DCSection
          id="modes"
          title="主题"
          subtitle="默认浅色暖白 + 樱粉花瓣。深色作为可选项。"
        >
          <DCArtboard id="m-light" label="C1 · 浅色 (默认)" width={W} height={H}>
            <Phone variant="petal" color="#e87aa3" dark={false} waveStyle="bars" windowMin={30} forceState={STATES.RECORDING} />
          </DCArtboard>
          <DCArtboard id="m-dark" label="C2 · 深色" width={W} height={H}>
            <Phone variant="petal" color="#e87aa3" dark={true} waveStyle="bars" windowMin={30} forceState={STATES.RECORDING} />
          </DCArtboard>
          <DCArtboard id="m-sage" label="C3 · 雾蓝" width={W} height={H}>
            <Phone variant="petal" color="#7fa3c5" dark={false} waveStyle="ribbon" windowMin={30} forceState={STATES.RECORDING} />
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection label="按钮">
          <TweakRadio label="风格" value={buttonVariant}
            options={[
              { value: 'petal',   label: '花瓣' },
              { value: 'rainbow', label: '七彩' },
              { value: 'siri',    label: 'Plasma' },
              { value: 'glass',   label: 'Glass' },
            ]}
            onChange={(v) => setTweak('buttonVariant', v)} />
          <TweakColor label="主色" value={primaryColor} onChange={(v) => setTweak('primaryColor', v)} />
        </TweakSection>

        <TweakSection label="主题">
          <TweakToggle label="深色模式" value={dark} onChange={(v) => setTweak('dark', v)} />
        </TweakSection>

        <TweakSection label="内容池">
          <TweakSlider label="自动汇集窗口" value={windowMin} min={10} max={60} step={5} unit="min"
            onChange={(v) => setTweak('windowMin', v)} />
        </TweakSection>

        <TweakSection label="动效">
          <TweakRadio label="录音波形" value={waveStyle}
            options={[
              { value: 'bars',   label: '柱状' },
              { value: 'ribbon', label: '丝带' },
              { value: 'dots',   label: '点阵' },
            ]}
            onChange={(v) => setTweak('waveStyle', v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
