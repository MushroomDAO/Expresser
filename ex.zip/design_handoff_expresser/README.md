# Handoff — Expresser (片刻的表达,生活的诗篇)

## Overview

**Expresser** 是一款"一颗按钮 = 一切"的轻量内容创作 App。核心交互:

- 一颗花瓣形主按钮,承担所有捕捉行为(语音 / 拍照 / 录像)
- 30 分钟滚动窗口的"内容池"模型 — 单次捕捉**不直接发布**,先入池
- 满 30 分钟自动汇成草稿 → 发前 5 秒倒计时 → 用户可拦截进入手动 Compose 配置页
- 横竖滑手势分担次要功能,避免菜单和按钮泛滥

主要差异化:把"创作 → 发布"从一次性动作改成异步聚合,降低发布心理负担。

## About the Design Files

`source/` 里的 HTML/JSX/CSS 是**设计参考稿**,不是产品代码。它们用 React + Babel 在浏览器里直出,用于精确表达视觉、动效、状态机和手势行为。

接手开发时,请把这些 HTML 设计**重新实现到目标代码库**(React Native / Flutter / SwiftUI / Jetpack Compose 等)中,使用项目自身的组件库与样式约定。如果项目尚未选定栈,推荐 React Native + Reanimated(因为本设计里大量用到了手势 + 60fps 动效)。

## Fidelity

**High-fidelity**。颜色、间距、字号、圆角、阴影、动效时序、手势阈值都是终态值,可以直接拿来用。

## Screens / States

主组件 `<ExpresserApp>` 内含一个状态机,共 13 个状态:

| State | 触发 | 视觉关键 |
|---|---|---|
| `IDLE` | 默认 | 居中花瓣按钮 + 大字标题 + 底部 toast |
| `RECORDING` | 按住 | 实时转录文字流式显示 + 红点 REC + 录音时长 |
| `TRANSITION` | 录音中上滑 >80px | 花瓣闭合成镜头快门动画 (520ms) |
| `CAMERA` | 上滑完成 | 全屏预览 + 4 种模式 + 大快门 |
| `CAPTURING` | 点击快门 | 280ms 闪光后入池 |
| `RECORDING_V` | 长按快门 320ms+ | 红色方块快门 + REC 计时 |
| `POOL` | 任何捕捉完成后 | 1.8s 浮现 "+ ADDED" + 内容池缩略图条 |
| `COUNTDOWN` | 点击 toast 主体 | 5 秒倒计时环 + 取消按钮 |
| `COMPOSE` | 右滑 / 点 toast 上"挑选" / 倒计时取消 | 全屏列表勾选片段 |
| `PROCESSING` | Compose 确认 / 倒计时结束 | 进度条 + "本地拼版" |
| `UPLOADING` | Processing 完成 | 进度条 + "同步至 NAS" |
| `PUBLISHED` | Upload 完成 | 4 个发布目标卡片 + ✓ 勾选 |
| `OFFLINE` | 网络断开 | 离线队列卡片 |

### IDLE — 主屏

- **背景**: 暖白 `#fbf7f1`,顶部右上角樱粉径向辉光
- **顶部**: 左 = 小花瓣 logo + "Expresser",右 = 内容池 pill(`{count} 片段 · X/30min`)
- **中部**: H1 大字 "片刻的表达,*生活的诗篇*" — 30px / 600 / -0.02em / `#1d1c1a`,"生活的诗篇" 部分 italic + opacity 0.7
- **副标题**: "自动汇成 30 分钟一篇 · 发前 5 秒可拦" — 13px / 0.55 opacity
- **花瓣按钮**: 188×188,真实重叠 6 瓣,详见 Components
- **手势提示**: 三颗胶囊 — `← 左滑换样式` `↑ 上滑相机` `→ 右滑挑选`
- **底部 toast**: 圆角 22px 玻璃卡片,见下

### Toast(底部草稿提示)

- 22px 圆角,白色 96% 透明 + 暖橘渐变,backdrop-filter blur 14px
- 阴影呼吸动画 4s(`ex-toast-glow`)
- 左侧 36px 圆形花瓣 icon (`#ffe9f0` → `#ffd2dd` 径向)
- 标题 "今天的片刻正在汇集" 14px / 600
- 副标题 "{N} 片段 · 还差 {M} 分钟自动开成一篇" 11.5px / 0.62 opacity
- 右侧粉色 CTA 按钮 "挑选" — 100px 圆,渐变 `#ff9ec0 → #e87aa3`
- 底部 3px 进度条,渐变 `#e87aa3 → #ffbe9c → #ffd28a`,宽度 = `windowProgress * 100%`

### Compose 页

- 头部: "COMPOSE" 标 + "挑选要合成的片段" + 计数与类型预测("将合成 vlog (含字幕)"或"将合成图文 blog")
- 列表项 (`.ex-piece`): 缩略图(语音=波形;照片/视频=渐变方块) + 类型 emoji + 文案 + 时间戳 + 右侧勾选
- 选中态: 内阴影粉色 1.5px + 背景粉色 12% 半透明 + 勾选填粉色
- 底部双按钮: 左"暂停 · 继续追加"(灰底);右"合成并发布 (N)"(主色填充)

## Interactions

### 手势(主按钮)

- **按住** ≥ 130ms 静止 → 进入 `RECORDING`(130ms 是为了让横滑能拦截)
- **录音中向上拖** > 80px → `TRANSITION → CAMERA`,松手不取消相机
- **横向滑动** |dx| > 16px 且 |dx| > |dy| × 1.4 → 标记为 swipe 模式,取消录音
  - 松手时 dx < -40 → **左滑**: 循环切换按钮风格 `petal → rainbow → siri → glass → petal`,中央闪 700ms 风格名 toast
  - 松手时 dx > 40 → **右滑**: 250ms 后跳到 `COMPOSE`
- **录音 < 600ms**: 视为误触,回 IDLE 不入池

### 相机内手势

- 点击大快门 → 拍照
- 长按 ≥ 320ms → 录像
- 顶部 ✕ 退回 IDLE
- 底部模式条横向滑选(AUTO / PORTRAIT / NIGHT / OBJECT)

### 自动发布流

```
[POOL fills to windowMin] → toast 显示满进度
   ↓ user taps toast body
COUNTDOWN (5s, ring sweep) ────[user cancels]──→ COMPOSE → confirmCompose → PROCESSING
   ↓ ctd === 0
PROCESSING (本地拼版, ~1.4s, 7%/100ms) → UPLOADING (~1.6s, 5%/80ms) → PUBLISHED (2.4s) → IDLE 复位
```

### 动效时序 / 缓动

| 动作 | 时长 | 缓动 |
|---|---|---|
| 按钮按下 | 180ms | `cubic-bezier(0.4, 0, 0.2, 1)` |
| 花瓣前后层摇摆 | 9s | `ease-in-out infinite` |
| 录音红环扩散 | 1.6s × 2(stagger 0.6s) | `ease-out infinite` |
| 录音中字幕进字 | 380ms / chunk | linear |
| 倒计时环 | 5s | linear forwards |
| 进度条 shimmer | 1.4s | linear infinite |
| Toast 入场 | 500ms | `cubic-bezier(0.2, 0.8, 0.2, 1)` |
| Swipe-flash 中央提示 | 700ms | ease forwards |
| Camera 进场 | 400ms | ease |
| Pool +ADDED 浮现 | 1.8s 后回 IDLE | — |

## State Management

```ts
type State = 'idle' | 'recording' | 'transition' | 'camera' | 'capturing'
           | 'recording_video' | 'pool' | 'countdown' | 'compose'
           | 'processing' | 'uploading' | 'published' | 'offline';

interface Piece {
  id: string;
  kind: 'voice' | 'photo' | 'video';
  t: string;            // capture timestamp HH:MM
  dur?: string;         // for voice/video
  text?: string;        // ASR transcript
  tag?: string;         // auto-classified tag
  cover?: 'warm' | 'cool' | 'mint';
  blobUri?: string;     // 实际数据
}

interface AppState {
  state: State;
  pool: Piece[];
  windowStart: Date;            // 池窗口起点,满 windowMin 自动触发草稿
  windowMin: number;            // 默认 30,可配 10–60
  draftPicks: Record<string, boolean>;  // compose 勾选
  variant: 'petal' | 'rainbow' | 'siri' | 'glass';  // 用户左滑选的样式,持久化
  dark: boolean;
  primaryColor: string;
  publishedTo: TargetId[];
  offlineQueue: DraftPayload[];
}
```

后端关键事件:
- `onCaptureFinished(piece)` → push pool, schedule auto-draft if window full
- `onAutoDraftDue()` → fire COUNTDOWN 5s
- `onPublish(picks)` → local AI compose → upload to NAS → fan-out to targets
- `onConnectivityChange(online)` → flush offlineQueue

## Design Tokens

### Colors

```css
/* Light theme (default) */
--ex-bg: #fbf7f1;
--ex-fg: #1d1c1a;
--ex-fg-sub: rgba(29,28,26,0.55);
--ex-card: rgba(0,0,0,0.04);

/* Dark theme */
--ex-bg-dark: #0e0f12;
--ex-fg-dark: #f5f4ef;
--ex-fg-sub-dark: rgba(245,244,239,0.55);
--ex-card-dark: rgba(255,255,255,0.05);

/* Brand */
--ex-primary: #e87aa3;          /* sakura pink */
--ex-primary-light: #ff9ec0;
--ex-stamen-1: #fff5c2;
--ex-stamen-2: #f5c454;
--ex-stamen-3: #b97a1f;

/* Semantic */
--ex-rec-red: #ff4d6a;
--ex-success: #3fbe6e;
--ex-warn: #e6a44b;

/* Rainbow gradient (used in 'rainbow' variant + toast progress) */
#ff8aa8 → #ffc887 → #fff09a → #a3e8b0 → #a4cfff → #d4a8ff
```

### Typography

- Font stack: `-apple-system, "SF Pro Text", "PingFang SC", system-ui, sans-serif`
- H1 (idle 主标题): 30px / 600 / -0.02em / 1.15
- H2 (其他状态标题): 22px / 600 / -0.015em / 1.25
- Body: 13px / 1.5
- Eyebrow: 11px / `ui-monospace` / 0.18em letter-spacing / 0.7 opacity
- Toast 标题: 14px / 600
- Toast 副: 11.5px / 0.62 opacity

### Spacing / Radius

- 主按钮: 188px(含基座阴影)
- 花瓣单瓣: len 58 × wid 42
- Toast 圆角: 22px
- Pill 圆角: 100px (full)
- 卡片圆角: 14px
- 列表项圆角: 14px

### Shadows

```css
/* Toast cushion */
0 14px 40px -10px rgba(232,122,163,0.32),
0 4px 14px -6px rgba(0,0,0,0.08)

/* Toast呼吸态 */
0 18px 46px -8px rgba(232,122,163,0.45),
0 6px 16px -6px rgba(0,0,0,0.10)

/* CTA button */
0 4px 12px -4px rgba(232,122,163,0.6)

/* Petal base ellipse */
soft ambient + dropshadow blur 2px under flower
```

## Assets

设计中所有图形(花瓣、相机镜头、波形、缩略图占位)均为**纯 SVG / CSS 渐变,无外部图片资源**。可直接用代码生成。

`PetalPath` 函数(在 `phone-app.jsx`)用极坐标参数化生成花瓣形状,可调 `petals` 与 `inner` 参数。

## Files in source/

- `Expresser.html` — 入口,加载顺序: React 18.3.1 → ReactDOM → Babel 7.29.0 → 启动器 → frame 组件 → tweaks panel → phone-app.jsx → app.jsx
- `phone-app.jsx` — `<ExpresserApp>` 主组件 + 状态机 + 手势 + 花瓣 SVG (~960 行)
- `app.jsx` — 演示画布 + Tweaks 面板封装(开发时使用,产品里不需要)
- `expresser.css` — 全部样式 + 关键帧动画

## 接入到你的 Claude Code 项目

如果你在用 React Native:

1. 把 `phone-app.jsx` 里的 `<ExpresserApp>` 拆成几个 RN 组件(状态机用 Zustand 或 React 自带 reducer)
2. 把 SVG petal 部分用 `react-native-svg` 重画(`petalShapePath` 算法可直接复用)
3. 手势用 `react-native-gesture-handler` 替换 PointerEvents,阈值不变
4. 录音 / 相机调系统 API,事件桥到本设计的状态机
5. 文案、颜色、动效时序按上面的 token 直接照搬

如果你在用 SwiftUI:

1. State machine 用 `@StateObject` ViewModel + enum
2. 花瓣 Path 用 `Shape` 协议实现 `petalShapePath` 算法
3. 手势用 `DragGesture` 做主按钮,`LongPressGesture` 做相机内长按录像
4. 动画值映射到 `withAnimation(.spring())` / `.easeInOut`

接入时把 `source/Expresser.html` 在浏览器打开作对照验收。
