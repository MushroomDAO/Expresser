// ─────────────────────────────────────────────────────────────
// Expresser — interactive phone prototype
// One round button. Press = record voice. Swipe up = camera.
// ─────────────────────────────────────────────────────────────

const STATES = {
  IDLE:        'idle',
  RECORDING:   'recording',         // pressing
  TRANSITION:  'transition',        // shutter opening
  CAMERA:      'camera',            // in camera; shutter open
  CAPTURING:   'capturing',         // taking a still
  RECORDING_V: 'recording_video',   // taking video
  PROCESSING:  'processing',        // local AI
  UPLOADING:   'uploading',         // cloud
  PUBLISHED:   'published',
  OFFLINE:     'offline',
};

// short helper
const cls = (...xs) => xs.filter(Boolean).join(' ');

// ── Waveform — animated, pure CSS bars driven by inline anim delays ─────
function Waveform({ active, style = 'bars', color = '#fff', count = 32 }) {
  const bars = [];
  for (let i = 0; i < count; i++) {
    const h = active
      ? 12 + Math.abs(Math.sin((i / count) * Math.PI * 3 + i * 0.7)) * 28
      : 4;
    if (style === 'dots') {
      bars.push(
        <div key={i} className="ex-wf-dot" style={{
          width: 6, height: 6, borderRadius: '50%',
          background: color, opacity: active ? 0.95 : 0.3,
          transform: active ? `translateY(${Math.sin(i * 0.6) * 6}px)` : 'none',
          animation: active ? `ex-bob 0.9s ${(i % 8) * 0.06}s ease-in-out infinite` : 'none',
        }} />
      );
    } else if (style === 'ribbon') {
      // continuous ribbon — single SVG path
      // handled outside this loop
      break;
    } else {
      bars.push(
        <div key={i} style={{
          width: 3, height: h, borderRadius: 2,
          background: color, opacity: active ? 0.92 : 0.32,
          animation: active ? `ex-pulse 0.8s ${(i % 10) * 0.05}s ease-in-out infinite alternate` : 'none',
        }} />
      );
    }
  }

  if (style === 'ribbon') {
    // procedural sine path
    const w = 280, h = 60, mid = h / 2;
    const pts = [];
    for (let i = 0; i <= 60; i++) {
      const x = (i / 60) * w;
      const y = mid + Math.sin(i * 0.45) * (active ? 14 : 2) * Math.sin(i * 0.13 + 1);
      pts.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return (
      <svg width={w} height={h} style={{ display: 'block' }}>
        <path d={pts.join(' ')} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
          style={{ animation: active ? 'ex-ribbon 1.2s linear infinite' : 'none', opacity: active ? 0.95 : 0.4 }} />
      </svg>
    );
  }

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      gap: style === 'dots' ? 8 : 4, height: 60,
    }}>
      {bars}
    </div>
  );
}

// ── The button itself — visuals only, gestures wrapped by parent ────────
function Orb({ variant, state, dark, color }) {
  const pressed = state === STATES.RECORDING || state === STATES.RECORDING_V;
  const camera  = state === STATES.CAMERA || state === STATES.CAPTURING || state === STATES.TRANSITION;
  const busy    = state === STATES.PROCESSING || state === STATES.UPLOADING;
  const done    = state === STATES.PUBLISHED;

  // four variants: solid, rainbow, siri, glass
  let bg, ring, glow, inner = null;

  if (variant === 'solid') {
    bg = `radial-gradient(circle at 35% 32%, ${tint(color, 0.35)}, ${color} 60%, ${shade(color, 0.5)} 100%)`;
    ring = pressed ? `0 0 0 14px ${color}22, 0 0 0 28px ${color}11` : `0 18px 50px -10px ${color}99`;
    glow = `0 0 70px -8px ${color}aa`;
  } else if (variant === 'rainbow') {
    bg = `conic-gradient(from var(--ex-ang, 0deg), #ff5e5e, #ffb84d, #ffe45e, #6bd86b, #5ec5ff, #b86bff, #ff5e9c, #ff5e5e)`;
    ring = `0 18px 60px -12px rgba(255,120,200,0.6), 0 0 0 1px rgba(255,255,255,0.08) inset`;
    glow = '';
    inner = (
      <div style={{
        position: 'absolute', inset: 6, borderRadius: '50%',
        background: dark
          ? 'radial-gradient(circle at 50% 40%, rgba(20,20,28,0.55), rgba(8,8,12,0.92) 75%)'
          : 'radial-gradient(circle at 50% 40%, rgba(255,255,255,0.85), rgba(245,243,250,0.92) 75%)',
        backdropFilter: 'blur(6px)',
      }} />
    );
  } else if (variant === 'siri') {
    bg = 'transparent';
    ring = `0 0 80px -8px rgba(110,180,255,0.55)`;
    glow = '';
    inner = (
      <>
        <div className="ex-siri ex-siri-1" />
        <div className="ex-siri ex-siri-2" />
        <div className="ex-siri ex-siri-3" />
      </>
    );
  } else { // glass
    bg = `linear-gradient(160deg, ${color}cc 0%, ${shade(color, 0.4)}ee 100%)`;
    ring = `0 22px 60px -16px ${color}99, inset 0 1px 0 rgba(255,255,255,0.5), inset 0 -8px 22px rgba(0,0,0,0.25)`;
    glow = `0 0 0 1px rgba(255,255,255,0.18) inset`;
    inner = (
      <>
        <div style={{
          position: 'absolute', top: 14, left: 22, width: 70, height: 36, borderRadius: '50%',
          background: 'radial-gradient(ellipse at center, rgba(255,255,255,0.85), rgba(255,255,255,0) 70%)',
          filter: 'blur(2px)',
        }} />
        <div style={{
          position: 'absolute', bottom: 18, right: 30, width: 30, height: 30, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,255,255,0.4), rgba(255,255,255,0) 70%)',
          filter: 'blur(3px)',
        }} />
      </>
    );
  }

  // shutter overlay — closing camera-iris animation
  const shutterOpen = camera || state === STATES.RECORDING_V;
  const blades = [];
  const bladeCount = 6;
  for (let i = 0; i < bladeCount; i++) {
    const ang = (i / bladeCount) * 360;
    blades.push(
      <div key={i} className="ex-blade" style={{
        transform: `rotate(${ang}deg) translateY(${shutterOpen ? '-95%' : '-3%'})`,
      }} />
    );
  }

  return (
    <div className={cls('ex-orb', pressed && 'ex-orb--pressed', busy && 'ex-orb--busy', done && 'ex-orb--done')}
      style={{
        background: bg,
        boxShadow: `${ring}${glow ? ',' + glow : ''}`,
        transform: pressed ? 'scale(0.94)' : busy ? 'scale(1.0)' : 'scale(1)',
      }}>
      {inner}

      {/* breathing ripple ring (idle) */}
      {state === STATES.IDLE && (
        <>
          <div className="ex-ripple" style={{ borderColor: variant === 'rainbow' ? '#ffffff66' : `${color}55` }} />
          <div className="ex-ripple ex-ripple-2" style={{ borderColor: variant === 'rainbow' ? '#ffffff44' : `${color}33` }} />
        </>
      )}

      {/* recording rings */}
      {pressed && (
        <>
          <div className="ex-rec-ring" />
          <div className="ex-rec-ring ex-rec-ring-2" />
        </>
      )}

      {/* lens shutter */}
      <div className={cls('ex-shutter', shutterOpen && 'ex-shutter--open')}>
        {blades}
        {/* lens glass when open */}
        <div className="ex-lens-glass" style={{ opacity: shutterOpen ? 1 : 0 }}>
          <div className="ex-lens-iris" />
          <div className="ex-lens-shine" />
        </div>
      </div>

      {/* processing dots */}
      {busy && (
        <div className="ex-busy">
          <span /><span /><span />
        </div>
      )}

      {/* checkmark */}
      {done && (
        <svg className="ex-check" viewBox="0 0 64 64" width="48" height="48">
          <path d="M14 33 L27 46 L50 20" fill="none" stroke="#fff" strokeWidth="6"
            strokeLinecap="round" strokeLinejoin="round"
            style={{ strokeDasharray: 80, strokeDashoffset: 0 }} />
        </svg>
      )}
    </div>
  );
}

function tint(hex, amt) {
  const { r, g, b } = parseHex(hex);
  return `rgb(${Math.min(255, r + (255 - r) * amt)|0}, ${Math.min(255, g + (255 - g) * amt)|0}, ${Math.min(255, b + (255 - b) * amt)|0})`;
}
function shade(hex, amt) {
  const { r, g, b } = parseHex(hex);
  return `rgb(${(r * (1 - amt))|0}, ${(g * (1 - amt))|0}, ${(b * (1 - amt))|0})`;
}
function parseHex(h) {
  const x = h.replace('#', '');
  return { r: parseInt(x.slice(0, 2), 16), g: parseInt(x.slice(2, 4), 16), b: parseInt(x.slice(4, 6), 16) };
}

// ── Camera modes ─────────────────────────────────────────────────────────
const CAM_MODES = [
  { id: 'auto',     label: 'AUTO',    sub: '自动' },
  { id: 'portrait', label: 'PORTRAIT', sub: '人像' },
  { id: 'night',    label: 'NIGHT',   sub: '夜景' },
  { id: 'object',   label: 'OBJECT',  sub: '实物' },
  { id: 'video',    label: 'VIDEO',   sub: '视频' },
];

// ── Publish targets ──────────────────────────────────────────────────────
const TARGETS = [
  { id: 'blog',  label: 'Personal blog',   sub: 'RSS' },
  { id: 'feed',  label: 'Photo feed',      sub: 'Image + caption' },
  { id: 'reels', label: 'Short video',     sub: 'Reel' },
  { id: 'nas',   label: 'Private archive', sub: 'NAS backup' },
];

// ── The transcript that builds while you talk ────────────────────────────
const TRANSCRIPT_CHUNKS = [
  '今天',
  '今天早上',
  '今天早上去了',
  '今天早上去了城东的',
  '今天早上去了城东的那家烘焙店',
  '今天早上去了城东的那家烘焙店,',
  '今天早上去了城东的那家烘焙店,可颂',
  '今天早上去了城东的那家烘焙店,可颂层次',
  '今天早上去了城东的那家烘焙店,可颂层次分明',
  '今天早上去了城东的那家烘焙店,可颂层次分明,黄油',
  '今天早上去了城东的那家烘焙店,可颂层次分明,黄油香气',
  '今天早上去了城东的那家烘焙店,可颂层次分明,黄油香气浓郁',
  '今天早上去了城东的那家烘焙店,可颂层次分明,黄油香气浓郁。',
];

// ─────────────────────────────────────────────────────────────
// Main app — owns gesture + state machine
// ─────────────────────────────────────────────────────────────
function ExpresserApp({
  variant = 'solid',
  color = '#ff4d5a',
  dark = true,
  waveStyle = 'bars',
  shutterStyle = 'iris',
  forceState = null,    // for static showcases: pin a single state
  onStateChange,
  compact = false,
}) {
  const [state, setStateRaw] = React.useState(forceState || STATES.IDLE);
  const [transcript, setTranscript] = React.useState('');
  const [recSeconds, setRecSeconds] = React.useState(0);
  const [camMode, setCamMode] = React.useState('auto');
  const [progress, setProgress] = React.useState(0); // 0–100, generic
  const [publishedTo, setPublishedTo] = React.useState([]);
  const [queueCount, setQueueCount] = React.useState(0);
  const [dragY, setDragY] = React.useState(0);

  // refs for gesture
  const startRef = React.useRef(null);
  const transcribeTimer = React.useRef(null);
  const recTimer = React.useRef(null);
  const flowTimer = React.useRef(null);

  const setState = (s) => {
    setStateRaw(s);
    onStateChange && onStateChange(s);
  };

  // handle external pin — also seed correlated data so frozen frames feel real
  React.useEffect(() => {
    if (!forceState) return;
    setStateRaw(forceState);
    if (forceState === STATES.RECORDING) {
      setTranscript('今天早上去了城东的那家烘焙店,可颂层次分明,黄油');
      setRecSeconds(7.4);
    }
    if (forceState === STATES.RECORDING_V) setRecSeconds(4.2);
    if (forceState === STATES.PROCESSING) setProgress(64);
    if (forceState === STATES.UPLOADING)  setProgress(38);
    if (forceState === STATES.PUBLISHED)  setPublishedTo(['blog', 'feed', 'nas']);
    if (forceState === STATES.OFFLINE)    setQueueCount(2);
  }, [forceState]);

  // recording timer
  React.useEffect(() => {
    if (state === STATES.RECORDING || state === STATES.RECORDING_V) {
      setRecSeconds(0);
      recTimer.current = setInterval(() => setRecSeconds(s => s + 0.1), 100);
    } else {
      clearInterval(recTimer.current);
    }
    return () => clearInterval(recTimer.current);
  }, [state]);

  // transcript animator while recording
  React.useEffect(() => {
    if (state === STATES.RECORDING) {
      setTranscript('');
      let i = 0;
      transcribeTimer.current = setInterval(() => {
        setTranscript(TRANSCRIPT_CHUNKS[i] || TRANSCRIPT_CHUNKS[TRANSCRIPT_CHUNKS.length - 1]);
        i++;
      }, 380);
    } else {
      clearInterval(transcribeTimer.current);
    }
    return () => clearInterval(transcribeTimer.current);
  }, [state]);

  // post-recording flow
  const finishVoice = () => {
    setState(STATES.PROCESSING);
    setProgress(0);
    let p = 0;
    flowTimer.current = setInterval(() => {
      p += 7;
      setProgress(Math.min(p, 100));
      if (p >= 100) {
        clearInterval(flowTimer.current);
        // simulate offline 1 in 5
        if (Math.random() < 0.0001) { // never; offline state opened explicitly
          setState(STATES.OFFLINE);
          setQueueCount(1);
        } else {
          setState(STATES.UPLOADING);
          setProgress(0);
          let q = 0;
          flowTimer.current = setInterval(() => {
            q += 5;
            setProgress(Math.min(q, 100));
            if (q >= 100) {
              clearInterval(flowTimer.current);
              setState(STATES.PUBLISHED);
              setPublishedTo(['blog', 'feed', 'nas']);
              setTimeout(() => {
                setState(STATES.IDLE);
                setPublishedTo([]);
                setTranscript('');
              }, 2400);
            }
          }, 80);
        }
      }
    }, 100);
  };

  // ── gesture handlers on the orb ───────────────────────────────────────
  const onPointerDown = (e) => {
    if (forceState) return;
    if (state !== STATES.IDLE) return;
    e.currentTarget.setPointerCapture && e.currentTarget.setPointerCapture(e.pointerId);
    startRef.current = { x: e.clientX, y: e.clientY, t: Date.now(), holdStarted: false };
    // tiny delay to distinguish from a swipe-without-record? Just start record now
    setState(STATES.RECORDING);
  };
  const onPointerMove = (e) => {
    if (!startRef.current) return;
    const dy = startRef.current.y - e.clientY;
    setDragY(Math.max(0, dy));
    // swipe up threshold → switch to camera transition
    if (dy > 80 && state === STATES.RECORDING) {
      setState(STATES.TRANSITION);
      setTranscript('');
      setTimeout(() => {
        setState(STATES.CAMERA);
      }, 520);
    }
  };
  const onPointerUp = (e) => {
    if (!startRef.current) return;
    const wasRecording = state === STATES.RECORDING;
    startRef.current = null;
    setDragY(0);
    if (wasRecording) {
      // finish voice flow
      if (recSeconds < 0.6) {
        setState(STATES.IDLE);
        setTranscript('');
      } else {
        finishVoice();
      }
    }
  };

  // shutter button in camera mode
  const onShutterTap = () => {
    if (state !== STATES.CAMERA) return;
    setState(STATES.CAPTURING);
    setTimeout(() => {
      // straight to processing→uploading→published
      finishVoice();
    }, 280);
  };
  const onShutterHold = () => {
    if (state !== STATES.CAMERA) return;
    setState(STATES.RECORDING_V);
    setTimeout(() => {
      finishVoice();
    }, 2400);
  };
  const closeCamera = () => {
    if (state === STATES.CAMERA) {
      setState(STATES.IDLE);
    }
  };

  // ── colors ────────────────────────────────────────────────────────────
  const bg = dark ? '#0a0a0c' : '#f6f4ef';
  const fg = dark ? '#f5f4ef' : '#16171a';
  const subFg = dark ? 'rgba(245,244,239,0.55)' : 'rgba(22,23,26,0.55)';
  const card = dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)';

  return (
    <div className={cls('ex-app', dark && 'ex-app--dark')} style={{
      width: '100%', height: '100%',
      background: bg, color: fg, position: 'relative', overflow: 'hidden',
      fontFamily: '-apple-system, "SF Pro Text", "Helvetica Neue", "PingFang SC", system-ui, sans-serif',
    }}>
      {/* ambient gradient — only in idle, subtle */}
      {(state === STATES.IDLE || state === STATES.PUBLISHED) && (
        <div className="ex-ambient" style={{
          background: variant === 'rainbow'
            ? `radial-gradient(60% 50% at 50% 70%, rgba(255,120,180,0.18), transparent 70%), radial-gradient(50% 40% at 70% 30%, rgba(110,180,255,0.16), transparent 70%)`
            : `radial-gradient(60% 50% at 50% 70%, ${color}26, transparent 70%)`,
          opacity: dark ? 1 : 0.55,
        }} />
      )}

      {/* TOP CHROME */}
      <Header state={state} dark={dark} fg={fg} subFg={subFg} queueCount={queueCount} />

      {/* MAIN STAGE */}
      <div className="ex-stage" style={{ paddingTop: compact ? 28 : 56 }}>

        {/* CONTEXT TEXT (above orb) */}
        <ContextText state={state} fg={fg} subFg={subFg} transcript={transcript}
          recSeconds={recSeconds} progress={progress} publishedTo={publishedTo} />

        {/* ORB (or camera viewfinder when in camera mode) */}
        {(state === STATES.CAMERA || state === STATES.CAPTURING || state === STATES.RECORDING_V || state === STATES.TRANSITION) ? (
          <CameraViewfinder
            state={state} dark={dark} color={color}
            mode={camMode} onModeChange={setCamMode}
            onShutterTap={onShutterTap} onShutterHold={onShutterHold}
            onClose={closeCamera}
            recSeconds={recSeconds}
          />
        ) : (
          <div className="ex-orb-wrap" style={{
            transform: `translateY(${-dragY * 0.5}px)`,
          }}>
            <div className="ex-orb-box"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              style={{ touchAction: 'none', cursor: forceState ? 'default' : 'grab' }}>
              <Orb variant={variant} state={state} dark={dark} color={color} />
            </div>

            {/* hint chips */}
            {state === STATES.IDLE && !forceState && (
              <div className="ex-hints">
                <div className="ex-hint">
                  <Icon kind="tap" />
                  <span>按住说话</span>
                </div>
                <div className="ex-hint">
                  <Icon kind="up" />
                  <span>上滑拍照</span>
                </div>
              </div>
            )}
            {state === STATES.RECORDING && (
              <div className="ex-wave-mount">
                <Waveform active style={waveStyle} color={dark ? '#fff' : '#222'} />
              </div>
            )}
            {state === STATES.OFFLINE && (
              <div className="ex-offline-card" style={{ background: card, color: fg }}>
                <div className="ex-offline-dot" />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>等待网络重新连接</div>
                  <div style={{ fontSize: 12, color: subFg, marginTop: 2 }}>
                    队列中 {queueCount} 项 · 网络恢复后自动续传
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* BOTTOM CHROME */}
      {!compact && state !== STATES.CAMERA && state !== STATES.CAPTURING && state !== STATES.RECORDING_V && state !== STATES.TRANSITION && (
        <BottomChrome state={state} dark={dark} fg={fg} subFg={subFg} publishedTo={publishedTo} />
      )}
    </div>
  );
}

// ── Header — small status row ────────────────────────────────────────────
function Header({ state, dark, fg, subFg, queueCount }) {
  const label = {
    [STATES.IDLE]:        'Expresser',
    [STATES.RECORDING]:   '正在听 · ASR 本地',
    [STATES.TRANSITION]:  '打开镜头…',
    [STATES.CAMERA]:      '相机',
    [STATES.CAPTURING]:   '正在拍摄',
    [STATES.RECORDING_V]: '录像中',
    [STATES.PROCESSING]:  '本地 AI 处理中',
    [STATES.UPLOADING]:   '同步至 NAS',
    [STATES.PUBLISHED]:   '已发布',
    [STATES.OFFLINE]:     '离线 · 已加入队列',
  }[state] || 'Expresser';

  return (
    <div className="ex-header" style={{ color: fg }}>
      <div className="ex-brand">
        <div className="ex-brand-mark" style={{ background: dark ? '#fff' : '#16171a' }} />
        <span style={{ fontWeight: 600, letterSpacing: '0.02em', fontSize: 15 }}>{label}</span>
      </div>
      <div className="ex-header-meta" style={{ color: subFg }}>
        {state === STATES.OFFLINE && (
          <span className="ex-pill ex-pill--warn">QUEUE {queueCount}</span>
        )}
        {(state === STATES.PROCESSING || state === STATES.UPLOADING) && (
          <span className="ex-pill">●  LIVE</span>
        )}
        {state === STATES.IDLE && (
          <span style={{ fontSize: 11, fontFamily: 'ui-monospace, SF Mono, Menlo, monospace' }}>
            ON-DEVICE READY
          </span>
        )}
      </div>
    </div>
  );
}

// ── Context text above the orb — guides through every state ─────────────
function ContextText({ state, fg, subFg, transcript, recSeconds, progress, publishedTo }) {
  const fmt = (s) => `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toFixed(0).padStart(2, '0')}`;

  if (state === STATES.IDLE) {
    return (
      <div className="ex-ctx ex-ctx--idle">
        <div className="ex-ctx-eyebrow">Hold &nbsp;·&nbsp; Speak &nbsp;·&nbsp; Publish</div>
        <h1 className="ex-ctx-title">让一刻 <em>变成</em> 一篇</h1>
        <div className="ex-ctx-sub" style={{ color: subFg }}>
          按住按钮说话 ‧ 上滑打开相机 ‧ 设备本地 AI 草稿 ‧ NAS 完工 ‧ 自动发布
        </div>
      </div>
    );
  }
  if (state === STATES.RECORDING) {
    return (
      <div className="ex-ctx ex-ctx--rec">
        <div className="ex-rec-meta">
          <span className="ex-rec-dot" />
          <span style={{ fontFamily: 'ui-monospace, SF Mono, Menlo, monospace', fontSize: 13 }}>
            REC &nbsp; {fmt(recSeconds)}
          </span>
          <span style={{ color: subFg, fontSize: 12, marginLeft: 8 }}>
            ASR · 本地
          </span>
        </div>
        <div className="ex-transcript">
          {transcript || <span style={{ color: subFg }}>开始说点什么…</span>}
          <span className="ex-cursor" />
        </div>
        <div className="ex-ctx-sub" style={{ color: subFg, marginTop: 18 }}>
          松手保存 ‧ 上滑切到相机
        </div>
      </div>
    );
  }
  if (state === STATES.PROCESSING || state === STATES.UPLOADING) {
    const isLocal = state === STATES.PROCESSING;
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow">{isLocal ? 'ON-DEVICE' : 'CLOUD · NAS @ home'}</div>
        <h2 className="ex-ctx-title2">
          {isLocal ? '正在本地分析' : '正在同步到家中 NAS'}
        </h2>
        <div className="ex-progress">
          <div className="ex-progress-bar" style={{ width: `${progress}%` }} />
        </div>
        <div className="ex-progress-meta" style={{ color: subFg }}>
          <span>{isLocal ? '提取要点 · 选封面 · 打草稿' : '剪辑 · 配字幕 · 排版'}</span>
          <span style={{ fontFamily: 'ui-monospace, SF Mono, Menlo, monospace' }}>{progress}%</span>
        </div>
      </div>
    );
  }
  if (state === STATES.PUBLISHED) {
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow" style={{ color: '#3fbe6e' }}>PUBLISHED</div>
        <h2 className="ex-ctx-title2">已发布到 {publishedTo.length} 个目标</h2>
        <div style={{ color: subFg, marginTop: 6, fontSize: 13 }}>
          预计阅读时长 2 分钟 ‧ 副本已存入 NAS
        </div>
      </div>
    );
  }
  if (state === STATES.OFFLINE) {
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow" style={{ color: '#e6a44b' }}>OFFLINE</div>
        <h2 className="ex-ctx-title2">先记着,联网后再发</h2>
      </div>
    );
  }
  return <div className="ex-ctx" />;
}

// ── Bottom chrome — publish targets row + tip ───────────────────────────
function BottomChrome({ state, dark, fg, subFg, publishedTo }) {
  return (
    <div className="ex-bottom">
      <div className="ex-targets">
        {TARGETS.map(t => {
          const lit = publishedTo.includes(t.id);
          return (
            <div key={t.id} className={cls('ex-target', lit && 'ex-target--lit')}
              style={{
                background: lit ? '#3fbe6e' : (dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)'),
                color: lit ? '#fff' : (dark ? '#f5f4ef' : '#16171a'),
              }}>
              <TargetIcon id={t.id} />
              <div className="ex-target-text">
                <div className="ex-target-label">{t.label}</div>
                <div className="ex-target-sub" style={{ color: lit ? 'rgba(255,255,255,0.85)' : subFg }}>
                  {t.sub}
                </div>
              </div>
              {lit && <div className="ex-target-tick">✓</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Camera viewfinder ──────────────────────────────────────────────────
function CameraViewfinder({ state, dark, color, mode, onModeChange, onShutterTap, onShutterHold, onClose, recSeconds }) {
  const isVid = state === STATES.RECORDING_V;
  const trans = state === STATES.TRANSITION;
  const [holdTimer, setHoldTimer] = React.useState(null);

  const onShutterDown = () => {
    const t = setTimeout(() => onShutterHold(), 320);
    setHoldTimer(t);
  };
  const onShutterUp = () => {
    if (holdTimer) {
      clearTimeout(holdTimer);
      setHoldTimer(null);
      if (state === STATES.CAMERA) onShutterTap();
    }
  };

  return (
    <div className={cls('ex-cam', trans && 'ex-cam--in')}>
      {/* faux scene */}
      <div className="ex-cam-scene">
        <div className="ex-cam-scene-grad" />
        <div className="ex-cam-scene-blob ex-cam-blob-1" />
        <div className="ex-cam-scene-blob ex-cam-blob-2" />
        <div className="ex-cam-scene-blob ex-cam-blob-3" />
        {/* grid */}
        <div className="ex-cam-grid">
          <div /><div /><div /><div />
        </div>
        {/* focus square */}
        <div className="ex-cam-focus" />
        {/* placeholder text */}
        <div className="ex-cam-placeholder">PREVIEW · {mode.toUpperCase()}</div>
      </div>

      {/* close */}
      <button className="ex-cam-close" onClick={onClose}>✕</button>

      {/* mode label top */}
      <div className="ex-cam-mode-top">
        {isVid ? (
          <>
            <span className="ex-rec-dot" />
            <span style={{ fontFamily: 'ui-monospace, monospace' }}>REC {recSeconds.toFixed(1)}s</span>
          </>
        ) : (
          <span style={{ fontFamily: 'ui-monospace, monospace' }}>● {mode.toUpperCase()}</span>
        )}
      </div>

      {/* mode wheel */}
      {!isVid && (
        <div className="ex-cam-modes">
          {CAM_MODES.map(m => (
            <button key={m.id}
              className={cls('ex-cam-mode', mode === m.id && 'ex-cam-mode--on')}
              onClick={() => onModeChange(m.id)}>
              <div className="ex-cam-mode-label">{m.label}</div>
              <div className="ex-cam-mode-sub">{m.sub}</div>
            </button>
          ))}
        </div>
      )}

      {/* shutter button */}
      <button
        className={cls('ex-cam-shutter', isVid && 'ex-cam-shutter--rec')}
        onPointerDown={onShutterDown}
        onPointerUp={onShutterUp}
        onPointerLeave={onShutterUp}>
        <div className="ex-cam-shutter-inner" />
      </button>

      {/* hint */}
      {!isVid && (
        <div className="ex-cam-hint">
          点击拍照 · 长按录像
        </div>
      )}
    </div>
  );
}

// ── small icons ─────────────────────────────────────────────────────────
function Icon({ kind }) {
  if (kind === 'tap') return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="3" fill="currentColor" />
      <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1" opacity="0.5" />
    </svg>
  );
  if (kind === 'up') return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M8 12 V4 M5 7 L8 4 L11 7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
  return null;
}

function TargetIcon({ id }) {
  if (id === 'blog') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M5 3 H15 L19 7 V21 H5 Z"/><path d="M9 11 H15 M9 15 H13"/></svg>;
  if (id === 'feed') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1.5" fill="currentColor"/><path d="M4 16 L9 12 L13 15 L17 11 L20 14"/></svg>;
  if (id === 'reels') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M10 10 L14 12.5 L10 15 Z" fill="currentColor"/><path d="M3 9 L21 9 M7 6 V3 M17 6 V3"/></svg>;
  if (id === 'nas') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="5" width="18" height="5" rx="1"/><rect x="3" y="14" width="18" height="5" rx="1"/><circle cx="17" cy="7.5" r="0.6" fill="currentColor"/><circle cx="17" cy="16.5" r="0.6" fill="currentColor"/></svg>;
  return null;
}

window.ExpresserApp = ExpresserApp;
window.STATES = STATES;
