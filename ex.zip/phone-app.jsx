// ─────────────────────────────────────────────────────────────
// Expresser v2 — content pool + 30min auto-aggregate + intercept
// One petal button. Press = voice. Swipe up = camera.
// All captures land in a 30-min rolling pool that auto-drafts a blog/vlog,
// with a 5s countdown the user can intercept to compose manually.
// ─────────────────────────────────────────────────────────────

const STATES = {
  IDLE:        'idle',
  RECORDING:   'recording',
  TRANSITION:  'transition',
  CAMERA:      'camera',
  CAPTURING:   'capturing',
  RECORDING_V: 'recording_video',
  POOL:        'pool',           // viewing the rolling pool of pieces
  COUNTDOWN:   'countdown',      // 5s intercept window before auto-publish
  COMPOSE:     'compose',        // user intercepted; pick pieces to combine
  PROCESSING:  'processing',
  UPLOADING:   'uploading',
  PUBLISHED:   'published',
  OFFLINE:     'offline',
};

const cls = (...xs) => xs.filter(Boolean).join(' ');

// ── Waveform ────────────────────────────────────────────────────────────
function Waveform({ active, style = 'bars', color = '#222', count = 32 }) {
  const bars = [];
  for (let i = 0; i < count; i++) {
    const h = active
      ? 12 + Math.abs(Math.sin((i / count) * Math.PI * 3 + i * 0.7)) * 28
      : 4;
    if (style === 'dots') {
      bars.push(<div key={i} style={{
        width: 6, height: 6, borderRadius: '50%',
        background: color, opacity: active ? 0.9 : 0.3,
        animation: active ? `ex-bob 0.9s ${(i % 8) * 0.06}s ease-in-out infinite` : 'none',
      }} />);
    } else {
      bars.push(<div key={i} style={{
        width: 3, height: h, borderRadius: 2,
        background: color, opacity: active ? 0.9 : 0.32,
        animation: active ? `ex-pulse 0.8s ${(i % 10) * 0.05}s ease-in-out infinite alternate` : 'none',
      }} />);
    }
  }
  if (style === 'ribbon') {
    const w = 280, h = 60, mid = h / 2;
    const pts = [];
    for (let i = 0; i <= 60; i++) {
      const x = (i / 60) * w;
      const y = mid + Math.sin(i * 0.45) * (active ? 14 : 2) * Math.sin(i * 0.13 + 1);
      pts.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return (
      <svg width={w} height={h} style={{ display: 'block' }}>
        <path d={pts.join(' ')} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
          style={{ animation: active ? 'ex-ribbon 1.2s linear infinite' : 'none', opacity: active ? 0.95 : 0.4 }} />
      </svg>
    );
  }
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: style === 'dots' ? 8 : 4, height: 60 }}>
      {bars}
    </div>
  );
}

// ── Petal SVG — six-petal rosette, used as clip + as decorative outline ─
function PetalPath({ size = 168, petals = 6, inner = 0.42 }) {
  // build a smooth rosette path from polar function r(θ) = inner + (1-inner)*cos(petals*θ/2)^2
  const pts = [];
  const N = 240;
  const cx = size / 2, cy = size / 2, R = size / 2;
  for (let i = 0; i <= N; i++) {
    const t = (i / N) * Math.PI * 2;
    const c = Math.cos((petals * t) / 2);
    const r = (inner + (1 - inner) * c * c) * R;
    const x = cx + Math.cos(t) * r;
    const y = cy + Math.sin(t) * r;
    pts.push(`${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`);
  }
  return pts.join(' ') + ' Z';
}

// ── Real petal — teardrop shape used as one bloom petal ──────────────
function petalShapePath(cx, cy, len, wid, angleDeg) {
  // teardrop with point at center, bulb at outer end
  // build in local coords then rotate
  const N = 40;
  const pts = [];
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    // x along petal axis 0 → len; width follows sin curve, sharp at base, round at tip
    const x = t * len;
    const w = Math.sin(Math.pow(t, 0.55) * Math.PI) * wid * 0.5;
    pts.push([x, w]);
  }
  for (let i = N; i >= 0; i--) {
    const t = i / N;
    const x = t * len;
    const w = -Math.sin(Math.pow(t, 0.55) * Math.PI) * wid * 0.5;
    pts.push([x, w]);
  }
  // rotate
  const a = (angleDeg * Math.PI) / 180;
  const ca = Math.cos(a), sa = Math.sin(a);
  const moved = pts.map(([x, y]) => [cx + x * ca - y * sa, cy + x * sa + y * ca]);
  return 'M ' + moved.map(([x, y], i) => `${i === 0 ? '' : 'L '}${x.toFixed(2)} ${y.toFixed(2)}`).join(' ') + ' Z';
}

function PetalButton({ state, color, dark, idPrefix = 'p' }) {
  const pressed = state === STATES.RECORDING || state === STATES.RECORDING_V;
  const camera  = state === STATES.CAMERA || state === STATES.CAPTURING || state === STATES.TRANSITION;
  const busy    = state === STATES.PROCESSING || state === STATES.UPLOADING;
  const done    = state === STATES.PUBLISHED;
  const ctd     = state === STATES.COUNTDOWN;
  const idle    = state === STATES.IDLE || state === STATES.POOL;

  const size = 220; // includes base shadow + glow halo space
  const cx = size / 2, cy = size / 2;
  const petalLen = 60;
  const petalWid = 44;
  const N = 6;
  const orbR = 86; // round button orb radius

  // derive complementary tints from `color`
  const lightTint = `${color}cc`;
  const deepTint  = color;

  return (
    <div className={cls('ex-petal', pressed && 'ex-petal--pressed', busy && 'ex-petal--busy', done && 'ex-petal--done')}>
      {/* Soft drop shadow under the whole flower (button cushion) */}
      <div className="ex-petal-shadow" />

      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ overflow: 'visible' }}>
        <defs>
          {/* gradient per petal — light at base, saturated near tip */}
          <radialGradient id={`${idPrefix}-pet`} cx="80%" cy="50%" r="70%">
            <stop offset="0%"   stopColor={deepTint}  stopOpacity="0.95" />
            <stop offset="55%"  stopColor={lightTint} stopOpacity="0.85" />
            <stop offset="100%" stopColor="#ffffff"   stopOpacity={dark ? 0.4 : 0.95} />
          </radialGradient>
          {/* center stamen radial */}
          <radialGradient id={`${idPrefix}-stamen`} cx="40%" cy="35%" r="70%">
            <stop offset="0%"  stopColor="#fff5c2" />
            <stop offset="55%" stopColor="#f5c454" />
            <stop offset="100%" stopColor="#b97a1f" />
          </radialGradient>
          {/* outer ambient glow — halo around the orb */}
          <radialGradient id={`${idPrefix}-glow`} cx="50%" cy="50%" r="50%">
            <stop offset="55%"  stopColor={color} stopOpacity="0" />
            <stop offset="72%"  stopColor={color} stopOpacity={pressed ? 0.32 : 0.18} />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </radialGradient>
          {/* orb body — glassy sphere, light from upper-left */}
          <radialGradient id={`${idPrefix}-orb`} cx="38%" cy="32%" r="82%">
            <stop offset="0%"   stopColor={dark ? '#2a2026' : '#ffffff'} stopOpacity={dark ? 0.85 : 1} />
            <stop offset="42%"  stopColor={dark ? '#1a1418' : '#fff4ea'} stopOpacity="1" />
            <stop offset="78%"  stopColor={dark ? '#0e0a0d' : '#fbe4d6'} stopOpacity="1" />
            <stop offset="100%" stopColor={dark ? '#070406' : '#f0c8b8'} stopOpacity="1" />
          </radialGradient>
          {/* inner-shadow ring at orb edge (the dark rim) */}
          <radialGradient id={`${idPrefix}-rim`} cx="50%" cy="50%" r="50%">
            <stop offset="86%"  stopColor="#000" stopOpacity="0" />
            <stop offset="100%" stopColor="#000" stopOpacity={dark ? 0.55 : 0.22} />
          </radialGradient>
          {/* glossy top highlight */}
          <radialGradient id={`${idPrefix}-gloss`} cx="50%" cy="22%" r="42%">
            <stop offset="0%"   stopColor="#ffffff" stopOpacity={dark ? 0.35 : 0.85} />
            <stop offset="60%"  stopColor="#ffffff" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* outer ambient halo — soft colored glow ring around the orb */}
        <circle cx={cx} cy={cy} r={orbR + 28} fill={`url(#${idPrefix}-glow)`} />

        {/* base orb — round, glassy, with light from upper-left */}
        <circle cx={cx} cy={cy + 2} r={orbR} fill={`url(#${idPrefix}-orb)`} />

        {/* dark rim — inner shadow at edge for depth */}
        <circle cx={cx} cy={cy + 2} r={orbR} fill={`url(#${idPrefix}-rim)`} />

        {/* outer hairline border */}
        <circle cx={cx} cy={cy + 2} r={orbR}
          fill="none"
          stroke={dark ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.95)'}
          strokeWidth="1.2" />

        {/* glossy top highlight — the bright crescent at the top */}
        <ellipse cx={cx} cy={cy - 30} rx={orbR * 0.78} ry={orbR * 0.46}
          fill={`url(#${idPrefix}-gloss)`} style={{ mixBlendMode: 'screen' }} />

        {/* back layer — slightly larger, rotated ½ angle, low opacity */}
        <g style={{ transformOrigin: `${cx}px ${cy}px`,
                    animation: idle ? 'ex-petal-sway 9s ease-in-out infinite' : 'none',
                    opacity: 0.55 }}>
          {Array.from({ length: N }).map((_, i) => {
            const a = (i / N) * 360 + (180 / N);
            return <path key={`b${i}`} d={petalShapePath(cx, cy, petalLen + 6, petalWid + 6, a)}
              fill={`url(#${idPrefix}-pet)`} opacity="0.7" />;
          })}
        </g>

        {/* front layer petals */}
        <g style={{ transformOrigin: `${cx}px ${cy}px`,
                    animation: idle ? 'ex-petal-sway-rev 9s ease-in-out infinite' : 'none' }}>
          {Array.from({ length: N }).map((_, i) => {
            const a = (i / N) * 360;
            const d = petalShapePath(cx, cy, petalLen, petalWid, a);
            return (
              <g key={`f${i}`}>
                <path d={d} fill={`url(#${idPrefix}-pet)`}
                  stroke={dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.7)'}
                  strokeWidth="0.8" />
                {/* highlight along upper edge */}
                <path d={d} fill="none" stroke="#ffffff" strokeOpacity={dark ? 0.15 : 0.55}
                  strokeWidth="1.2" style={{ filter: 'blur(0.5px)' }} />
              </g>
            );
          })}
        </g>

        {/* center stamen */}
        <circle cx={cx} cy={cy} r="14" fill={`url(#${idPrefix}-stamen)`}
          stroke="rgba(120,80,20,0.3)" strokeWidth="0.6" />
        {/* stamen dots */}
        {[0, 60, 120, 180, 240, 300].map(a => {
          const r = 8;
          const x = cx + Math.cos(a * Math.PI / 180) * r;
          const y = cy + Math.sin(a * Math.PI / 180) * r;
          return <circle key={a} cx={x} cy={y} r="1.4" fill="#7a4e10" opacity="0.6" />;
        })}
        {/* breathing pollen highlight when idle */}
        {idle && (
          <circle cx={cx - 3} cy={cy - 3} r="4" fill="#fff8d8"
            style={{ transformOrigin: `${cx}px ${cy}px`, animation: 'ex-petal-breathe 2.8s ease-in-out infinite' }} />
        )}

        {/* recording: red ring expanding from stamen */}
        {pressed && (
          <>
            <circle cx={cx} cy={cy} r="14" fill="none" stroke="#ff4d6a" strokeWidth="2"
              style={{ transformOrigin: `${cx}px ${cy}px`, animation: 'ex-rec-ring 1.6s ease-out infinite' }} />
            <circle cx={cx} cy={cy} r="14" fill="none" stroke="#ff4d6a" strokeWidth="2"
              style={{ transformOrigin: `${cx}px ${cy}px`, animation: 'ex-rec-ring 1.6s ease-out infinite 0.6s' }} />
            <circle cx={cx} cy={cy} r="6" fill="#ff4d6a" />
          </>
        )}

        {/* countdown ring around stamen */}
        {ctd && (
          <circle cx={cx} cy={cy} r="34" fill="none" stroke={color} strokeWidth="3"
            strokeDasharray={2 * Math.PI * 34}
            style={{ animation: 'ex-ctd-ring 5s linear forwards', transformOrigin: `${cx}px ${cy}px`, transform: 'rotate(-90deg)' }} />
        )}

        {/* busy dots in stamen */}
        {busy && (
          <g transform={`translate(${cx - 14}, ${cy})`}>
            <circle cx="0"  cy="0" r="3" fill="#fff" style={{ animation: 'ex-busy-dot 1.2s ease-in-out infinite' }} />
            <circle cx="14" cy="0" r="3" fill="#fff" style={{ animation: 'ex-busy-dot 1.2s ease-in-out infinite 0.18s' }} />
            <circle cx="28" cy="0" r="3" fill="#fff" style={{ animation: 'ex-busy-dot 1.2s ease-in-out infinite 0.36s' }} />
          </g>
        )}

        {/* check on publish */}
        {done && (
          <g stroke="#3fbe6e" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" fill="none">
            <path d={`M ${cx - 16} ${cy + 1} L ${cx - 4} ${cy + 13} L ${cx + 18} ${cy - 9}`} />
          </g>
        )}

        {/* lens overlay when in camera mode — sits over flower */}
        {camera && (
          <g>
            <circle cx={cx} cy={cy} r={petalLen + 4} fill="#0a0a0c" opacity="0.86" />
            <circle cx={cx} cy={cy} r={petalLen / 1.6} fill="#1d2842" />
            <circle cx={cx} cy={cy} r={petalLen / 2.6} fill="#5e80c2" />
            <circle cx={cx - 8} cy={cy - 6} r="6" fill="#fff" opacity="0.85" />
          </g>
        )}
      </svg>
    </div>
  );
}

// ── Original orb variants kept for variant gallery ──────────────────────
function Orb({ variant, state, dark, color }) {
  if (variant === 'petal') return <PetalButton state={state} color={color} dark={dark} idPrefix={`o-${state}`} />;
  // (other variants kept for the variants section)
  const pressed = state === STATES.RECORDING || state === STATES.RECORDING_V;
  const busy    = state === STATES.PROCESSING || state === STATES.UPLOADING;
  const done    = state === STATES.PUBLISHED;
  let bg, ring, inner = null;
  if (variant === 'rainbow') {
    bg = `conic-gradient(from 0deg, #ff8aa8, #ffc887, #fff09a, #a3e8b0, #a4cfff, #d4a8ff, #ff8aa8)`;
    ring = `0 18px 60px -12px rgba(220,160,200,0.5), 0 0 0 1px rgba(255,255,255,0.08) inset`;
    inner = (
      <div style={{
        position: 'absolute', inset: 6, borderRadius: '50%',
        background: dark ? 'rgba(15,15,20,0.92)' : 'rgba(253,252,250,0.94)',
      }} />
    );
  } else if (variant === 'siri') {
    bg = 'transparent';
    ring = `0 0 80px -8px rgba(110,180,255,0.45)`;
    inner = (<><div className="ex-siri ex-siri-1"/><div className="ex-siri ex-siri-2"/><div className="ex-siri ex-siri-3"/></>);
  } else { // glass / solid fallback
    const c = color;
    bg = `linear-gradient(160deg, ${c}cc 0%, ${c}88 100%)`;
    ring = `0 22px 60px -16px ${c}99, inset 0 1px 0 rgba(255,255,255,0.5)`;
  }
  return (
    <div className={cls('ex-orb', pressed && 'ex-orb--pressed', busy && 'ex-orb--busy', done && 'ex-orb--done')}
      style={{ background: bg, boxShadow: ring }}>
      {inner}
      {state === STATES.IDLE && (
        <>
          <div className="ex-ripple" style={{ borderColor: `${color}55` }} />
          <div className="ex-ripple ex-ripple-2" style={{ borderColor: `${color}33` }} />
        </>
      )}
      {pressed && (<><div className="ex-rec-ring" /><div className="ex-rec-ring ex-rec-ring-2" /></>)}
      {busy && (<div className="ex-busy"><span /><span /><span /></div>)}
      {done && (
        <svg viewBox="0 0 64 64" width="48" height="48" style={{ position: 'absolute' }}>
          <path d="M14 33 L27 46 L50 20" fill="none" stroke="#fff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
    </div>
  );
}

// ── Camera modes ────────────────────────────────────────────────────────
const CAM_MODES = [
  { id: 'auto',     label: 'AUTO',    sub: '自动' },
  { id: 'portrait', label: 'PORTRAIT', sub: '人像' },
  { id: 'night',    label: 'NIGHT',   sub: '夜景' },
  { id: 'object',   label: 'OBJECT',  sub: '实物' },
];

const TARGETS = [
  { id: 'blog',  label: 'Personal blog',   sub: 'RSS' },
  { id: 'feed',  label: 'Photo feed',      sub: 'Image + caption' },
  { id: 'reels', label: 'Short video',     sub: 'Reel' },
  { id: 'nas',   label: 'Private archive', sub: 'NAS backup' },
];

const TRANSCRIPT_CHUNKS = [
  '今天','今天早上','今天早上去了','今天早上去了城东的','今天早上去了城东的那家烘焙店',
  '今天早上去了城东的那家烘焙店,','今天早上去了城东的那家烘焙店,可颂',
  '今天早上去了城东的那家烘焙店,可颂层次分明',
  '今天早上去了城东的那家烘焙店,可颂层次分明,黄油香气浓郁。',
];

// ── A pool of pieces shown in the pool view + compose view ──────────────
const SAMPLE_POOL = [
  { id: 'p1', kind: 'voice', t: '08:42', dur: '00:14', text: '今天早上的可颂层次分明,黄油香气浓郁。', tag: '美食' },
  { id: 'p2', kind: 'photo', t: '08:43', tag: '美食', cover: 'warm' },
  { id: 'p3', kind: 'photo', t: '08:51', tag: '街景', cover: 'cool' },
  { id: 'p4', kind: 'voice', t: '09:04', dur: '00:22', text: '河边的风很舒服,芦苇荡得很有节奏。', tag: '心情' },
  { id: 'p5', kind: 'video', t: '09:08', dur: '00:38', tag: '日常', cover: 'warm' },
  { id: 'p6', kind: 'photo', t: '09:14', tag: '日常', cover: 'mint' },
  { id: 'p7', kind: 'voice', t: '09:19', dur: '00:08', text: '想顺路买一束含羞草。', tag: '心情' },
];

// ─────────────────────────────────────────────────────────────
function ExpresserApp({
  variant = 'petal',
  color = '#e87aa3',
  dark = false,
  waveStyle = 'bars',
  forceState = null,
  windowMin = 30,
  onStateChange,
  compact = false,
}) {
  const [state, setStateRaw] = React.useState(forceState || STATES.IDLE);
  const [transcript, setTranscript] = React.useState('');
  const [recSeconds, setRecSeconds] = React.useState(0);
  const [camMode, setCamMode] = React.useState('auto');
  const [progress, setProgress] = React.useState(0);
  const [publishedTo, setPublishedTo] = React.useState([]);
  const [queueCount, setQueueCount] = React.useState(0);
  const [dragY, setDragY] = React.useState(0);
  const [dragX, setDragX] = React.useState(0);
  const [localVariant, setLocalVariant] = React.useState(null); // override for swipe-cycle
  const [swipeFlash, setSwipeFlash] = React.useState(null); // 'left' | 'right'
  const [poolCount, setPoolCount] = React.useState(7);
  const [windowProgress, setWindowProgress] = React.useState(0.62); // 0–1 of windowMin
  const [ctd, setCtd] = React.useState(5);
  const [selectedPieces, setSelectedPieces] = React.useState({ p1: true, p2: true, p4: true, p5: true });
  const [darkOverride, setDarkOverride] = React.useState(null); // user toggle wins over prop
  const [overlay, setOverlay] = React.useState(null); // 'about' | 'pool' | null

  const startRef = React.useRef(null);
  const transcribeTimer = React.useRef(null);
  const recTimer = React.useRef(null);
  const flowTimer = React.useRef(null);
  const ctdTimer = React.useRef(null);

  const setState = (s) => { setStateRaw(s); onStateChange && onStateChange(s); };

  // External pin — also seed correlated data so frozen frames feel real
  React.useEffect(() => {
    if (!forceState) return;
    setStateRaw(forceState);
    if (forceState === STATES.RECORDING) { setTranscript('今天早上去了城东的那家烘焙店,可颂层次分明,黄油'); setRecSeconds(7.4); }
    if (forceState === STATES.RECORDING_V) setRecSeconds(4.2);
    if (forceState === STATES.PROCESSING) setProgress(64);
    if (forceState === STATES.UPLOADING)  setProgress(38);
    if (forceState === STATES.PUBLISHED)  setPublishedTo(['blog', 'feed', 'nas']);
    if (forceState === STATES.OFFLINE)    setQueueCount(2);
    if (forceState === STATES.COUNTDOWN)  setCtd(3);
    if (forceState === STATES.POOL)       setPoolCount(7);
  }, [forceState]);

  // recording timer
  React.useEffect(() => {
    if (state === STATES.RECORDING || state === STATES.RECORDING_V) {
      setRecSeconds(0);
      recTimer.current = setInterval(() => setRecSeconds(s => s + 0.1), 100);
    } else clearInterval(recTimer.current);
    return () => clearInterval(recTimer.current);
  }, [state]);

  // transcript animator
  React.useEffect(() => {
    if (state === STATES.RECORDING) {
      setTranscript('');
      let i = 0;
      transcribeTimer.current = setInterval(() => {
        setTranscript(TRANSCRIPT_CHUNKS[i] || TRANSCRIPT_CHUNKS[TRANSCRIPT_CHUNKS.length - 1]);
        i++;
      }, 380);
    } else clearInterval(transcribeTimer.current);
    return () => clearInterval(transcribeTimer.current);
  }, [state]);

  // post-recording → into POOL (not auto-publish)
  const finishCapture = () => {
    setPoolCount(c => c + 1);
    // brief flash showing the pool grew, then back to idle
    setState(STATES.POOL);
    setTimeout(() => { if (!forceState) setState(STATES.IDLE); }, 1800);
  };

  // gestures — press = record, up swipe = camera, left swipe = cycle variant, right swipe = compose
  const VARIANTS = ['petal', 'rainbow', 'siri', 'glass'];
  const effectiveVariant = localVariant || variant;

  const onPointerDown = (e) => {
    if (forceState) return;
    if (state !== STATES.IDLE && state !== STATES.POOL) return;
    e.currentTarget.setPointerCapture && e.currentTarget.setPointerCapture(e.pointerId);
    startRef.current = { x: e.clientX, y: e.clientY, t: Date.now(), recordStarted: false };
    // delay recording until we're confident this isn't a horizontal swipe
    const id = setTimeout(() => {
      if (startRef.current && !startRef.current.swipe) {
        startRef.current.recordStarted = true;
        setState(STATES.RECORDING);
      }
    }, 130);
    startRef.current.recTimer = id;
  };
  const onPointerMove = (e) => {
    if (!startRef.current) return;
    const dx = e.clientX - startRef.current.x;
    const dy = startRef.current.y - e.clientY;
    const adx = Math.abs(dx), ady = Math.abs(dy);

    // detect horizontal swipe early — cancels recording
    if (!startRef.current.recordStarted && adx > 16 && adx > ady * 1.4) {
      startRef.current.swipe = true;
      clearTimeout(startRef.current.recTimer);
      setDragX(dx);
      setDragY(0);
      return;
    }
    if (startRef.current.swipe) {
      setDragX(dx);
      return;
    }

    // vertical drag = camera open
    setDragY(Math.max(0, dy));
    if (dy > 80 && state === STATES.RECORDING) {
      setState(STATES.TRANSITION);
      setTranscript('');
      setTimeout(() => setState(STATES.CAMERA), 520);
    }
  };
  const onPointerUp = () => {
    if (!startRef.current) return;
    const ref = startRef.current;
    const wasRecording = state === STATES.RECORDING;
    clearTimeout(ref.recTimer);

    if (ref.swipe) {
      const finalDx = dragX;
      const SWIPE_THRESHOLD = 40;
      if (finalDx < -SWIPE_THRESHOLD) {
        // left swipe → cycle variant forward
        const cur = VARIANTS.indexOf(effectiveVariant);
        const next = VARIANTS[(cur + 1) % VARIANTS.length];
        setLocalVariant(next);
        setSwipeFlash('left');
        setTimeout(() => setSwipeFlash(null), 700);
      } else if (finalDx > SWIPE_THRESHOLD) {
        // right swipe → enter compose
        setSwipeFlash('right');
        setTimeout(() => { setSwipeFlash(null); setState(STATES.COMPOSE); }, 250);
      }
    } else if (wasRecording) {
      if (recSeconds < 0.6) { setState(STATES.IDLE); setTranscript(''); }
      else finishCapture();
    }
    startRef.current = null;
    setDragX(0);
    setDragY(0);
  };

  const onShutterTap = () => {
    if (state !== STATES.CAMERA) return;
    setState(STATES.CAPTURING);
    setTimeout(() => finishCapture(), 280);
  };
  const onShutterHold = () => {
    if (state !== STATES.CAMERA) return;
    setState(STATES.RECORDING_V);
    setTimeout(() => finishCapture(), 2400);
  };
  const closeCamera = () => { if (state === STATES.CAMERA) setState(STATES.IDLE); };

  // countdown — start when user taps the "auto-draft ready" pill
  const startCountdown = () => {
    setState(STATES.COUNTDOWN);
    setCtd(5);
    let n = 5;
    ctdTimer.current = setInterval(() => {
      n -= 1;
      setCtd(n);
      if (n <= 0) {
        clearInterval(ctdTimer.current);
        runPublishFlow();
      }
    }, 1000);
  };
  const cancelCountdown = () => {
    clearInterval(ctdTimer.current);
    setState(STATES.COMPOSE);
  };
  const confirmCompose = () => {
    setState(STATES.PROCESSING);
    runPublishFlow();
  };

  const runPublishFlow = () => {
    setState(STATES.PROCESSING);
    setProgress(0);
    let p = 0;
    flowTimer.current = setInterval(() => {
      p += 7;
      setProgress(Math.min(p, 100));
      if (p >= 100) {
        clearInterval(flowTimer.current);
        setState(STATES.UPLOADING);
        setProgress(0);
        let q = 0;
        flowTimer.current = setInterval(() => {
          q += 5;
          setProgress(Math.min(q, 100));
          if (q >= 100) {
            clearInterval(flowTimer.current);
            setState(STATES.PUBLISHED);
            setPublishedTo(['blog', 'feed', 'nas']);
            setTimeout(() => {
              if (!forceState) {
                setState(STATES.IDLE);
                setPublishedTo([]);
                setTranscript('');
                setPoolCount(0);
              }
            }, 2400);
          }
        }, 80);
      }
    }, 100);
  };

  // colors
  const effDark = darkOverride !== null ? darkOverride : dark;
  const bg = effDark ? '#0e0f12' : '#fbf7f1';
  const fg = effDark ? '#f5f4ef' : '#1d1c1a';
  const subFg = effDark ? 'rgba(245,244,239,0.55)' : 'rgba(29,28,26,0.55)';
  const card = effDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)';

  const inCamera = state === STATES.CAMERA || state === STATES.CAPTURING || state === STATES.RECORDING_V || state === STATES.TRANSITION;
  const inCompose = state === STATES.COMPOSE;
  const inPool = state === STATES.POOL;

  return (
    <div className={cls('ex-app', effDark ? 'ex-app--dark' : 'ex-app--light')}
      style={{ width: '100%', height: '100%', background: bg, color: fg, position: 'relative', overflow: 'hidden',
        fontFamily: '-apple-system, "SF Pro Text", "PingFang SC", system-ui, sans-serif' }}>
      {/* ambient warm gradient */}
      {!inCamera && !inCompose && (
        <div className="ex-ambient" style={{
          background: dark
            ? `radial-gradient(60% 50% at 50% 80%, ${color}33, transparent 70%), radial-gradient(50% 45% at 70% 25%, rgba(120,180,255,0.12), transparent 70%)`
            : `radial-gradient(60% 50% at 50% 80%, ${color}26, transparent 70%), radial-gradient(50% 45% at 80% 20%, rgba(255,200,180,0.30), transparent 70%)`,
        }} />
      )}

      <Header state={state} dark={effDark} fg={fg} subFg={subFg} queueCount={queueCount}
        poolCount={poolCount} windowMin={windowMin} windowProgress={windowProgress}
        interactive={!forceState}
        onAbout={() => setOverlay('about')}
        onPool={() => setOverlay('pool')}
        onToggleDark={() => setDarkOverride(d => !(d !== null ? d : dark))} />

      <div className="ex-stage" style={{ paddingTop: compact ? 24 : 48 }}>
        {/* CONTEXT */}
        {!inCamera && !inCompose && (
          <ContextText state={state} fg={fg} subFg={subFg} transcript={transcript}
            recSeconds={recSeconds} progress={progress} publishedTo={publishedTo}
            ctd={ctd} poolCount={poolCount} windowMin={windowMin}
            onStartCountdown={startCountdown} onCancelCountdown={cancelCountdown} />
        )}

        {/* MAIN STAGE */}
        {inCompose ? (
          <ComposeView pool={SAMPLE_POOL} selected={selectedPieces}
            onToggle={(id) => setSelectedPieces(s => ({ ...s, [id]: !s[id] }))}
            onConfirm={confirmCompose} onCancel={() => { if (!forceState) setState(STATES.IDLE); }}
            dark={effDark} color={color} subFg={subFg} card={card} />
        ) : inCamera ? (
          <CameraViewfinder state={state} dark={effDark} color={color}
            mode={camMode} onModeChange={setCamMode}
            onShutterTap={onShutterTap} onShutterHold={onShutterHold}
            onClose={closeCamera} recSeconds={recSeconds} />
        ) : (
          <div className="ex-orb-wrap" style={{ transform: `translate(${dragX * 0.4}px, ${-dragY * 0.5}px)` }}>
            <div className="ex-orb-box"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              style={{ touchAction: 'none', cursor: forceState ? 'default' : 'grab' }}>
              <Orb variant={effectiveVariant} state={state} dark={effDark} color={color} />
            </div>

            {state === STATES.IDLE && !forceState && (
              <div className="ex-hints">
                <div className="ex-hint"><Icon kind="left" /><span>左滑换样式</span></div>
                <div className="ex-hint"><Icon kind="up" /><span>上滑相机</span></div>
                <div className="ex-hint"><Icon kind="right" /><span>右滑挑选</span></div>
              </div>
            )}

            {swipeFlash && (
              <div className={cls('ex-swipe-flash', `ex-swipe-flash--${swipeFlash}`)}>
                {swipeFlash === 'left' ? `${effectiveVariant.toUpperCase()}` : '挑选片段 →'}
              </div>
            )}
            {state === STATES.RECORDING && (
              <div className="ex-wave-mount">
                <Waveform active style={waveStyle} color={dark ? '#fff' : '#222'} />
              </div>
            )}
            {inPool && (
              <PoolStrip pool={SAMPLE_POOL.slice(0, Math.min(SAMPLE_POOL.length, poolCount))}
                dark={effDark} subFg={subFg} card={card} />
            )}
            {state === STATES.OFFLINE && (
              <div className="ex-offline-card" style={{ background: card, color: fg }}>
                <div className="ex-offline-dot" />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>等待网络重新连接</div>
                  <div style={{ fontSize: 12, color: subFg, marginTop: 2 }}>队列中 {queueCount} 项 · 网络恢复后自动续传</div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* BOTTOM */}
      {!compact && !inCamera && !inCompose && (
        <BottomChrome state={state} dark={effDark} fg={fg} subFg={subFg}
          publishedTo={publishedTo} poolCount={poolCount} windowMin={windowMin}
          windowProgress={windowProgress}
          onTapDraft={startCountdown}
          onCompose={() => setState(STATES.COMPOSE)}
          card={card} />
      )}

      {/* OVERLAYS */}
      {overlay === 'about' && (
        <AboutOverlay onClose={() => setOverlay(null)} dark={effDark} fg={fg} subFg={subFg} color={color} />
      )}
      {overlay === 'pool' && (
        <PoolOverlay onClose={() => setOverlay(null)} dark={effDark} fg={fg} subFg={subFg} card={card}
          pool={SAMPLE_POOL.slice(0, Math.min(SAMPLE_POOL.length, poolCount))}
          poolCount={poolCount} windowMin={windowMin} windowProgress={windowProgress}
          onCompose={() => { setOverlay(null); setState(STATES.COMPOSE); }} />
      )}
    </div>
  );
}

// ── About / Pool overlays ───────────────────────────────────────────────
function AboutOverlay({ onClose, dark, fg, subFg, color }) {
  return (
    <div className="ex-overlay" onClick={onClose}>
      <div className={cls('ex-sheet', dark && 'ex-sheet--dark')} onClick={(e) => e.stopPropagation()}>
        <div className="ex-sheet-grip" />
        <button className="ex-sheet-close" onClick={onClose} aria-label="关闭">✕</button>
        <div className="ex-sheet-body">
          <div className="ex-about-mark">
            <div className="ex-about-petal-wrap">
              <Petal size={52} color={color} />
            </div>
          </div>
          <div className="ex-about-eyebrow" style={{ color: subFg }}>ABOUT</div>
          <h2 className="ex-about-title">Expresser</h2>
          <div className="ex-about-tag" style={{ color: subFg }}>片刻的表达,生活的诗篇</div>

          <div className="ex-about-body">
            <p>一颗按钮,捕捉日常碎片。无须排版、无须思考要发哪里。</p>
            <p style={{ color: subFg }}>
              按住说话、上滑拍照、左滑换样式、右滑挑选。捕捉的内容会先汇入 30 分钟的内容池,
              满了之后 AI 自动拼成一篇图文 vlog,发前 5 秒可以拦截。
            </p>
          </div>

          <div className="ex-about-grid">
            <div className="ex-about-cell">
              <div className="ex-about-num" style={{ color }}>30</div>
              <div className="ex-about-cell-label" style={{ color: subFg }}>分钟内容窗口</div>
            </div>
            <div className="ex-about-cell">
              <div className="ex-about-num" style={{ color }}>5s</div>
              <div className="ex-about-cell-label" style={{ color: subFg }}>发布前可拦截</div>
            </div>
            <div className="ex-about-cell">
              <div className="ex-about-num" style={{ color }}>4</div>
              <div className="ex-about-cell-label" style={{ color: subFg }}>同步目标</div>
            </div>
          </div>

          <div className="ex-about-foot" style={{ color: subFg }}>v0.2 · 私有 NAS · 本地 ASR</div>
        </div>
      </div>
    </div>
  );
}

function PoolOverlay({ onClose, dark, fg, subFg, card, pool, poolCount, windowMin, windowProgress, onCompose }) {
  const remaining = Math.max(0, windowMin - Math.round(windowProgress * windowMin));
  return (
    <div className="ex-overlay" onClick={onClose}>
      <div className={cls('ex-sheet', dark && 'ex-sheet--dark')} onClick={(e) => e.stopPropagation()}>
        <div className="ex-sheet-grip" />
        <button className="ex-sheet-close" onClick={onClose} aria-label="关闭">✕</button>
        <div className="ex-sheet-body">
          <div className="ex-about-eyebrow" style={{ color: subFg }}>POOL · 内容池</div>
          <h2 className="ex-about-title">今天的 {poolCount} 个片段</h2>
          <div className="ex-about-tag" style={{ color: subFg }}>
            还差 {remaining} 分钟自动汇成草稿
          </div>

          <div className="ex-pool-bar">
            <div className="ex-pool-bar-fill" style={{ width: `${windowProgress * 100}%` }} />
          </div>

          <div className="ex-pool-list">
            {pool.map(p => (
              <div key={p.id} className="ex-pool-item" style={{ background: card }}>
                <PoolThumb piece={p} dark={dark} />
                <div className="ex-pool-item-body">
                  <div className="ex-pool-item-row1">
                    <span className="ex-pool-item-kind">
                      {p.kind === 'voice' ? '🎙' : p.kind === 'photo' ? '📷' : '🎬'} {p.tag || ''}
                    </span>
                    <span style={{ color: subFg, fontFamily: 'ui-monospace, monospace', fontSize: 11 }}>
                      {p.t}{p.dur ? ` · ${p.dur}` : ''}
                    </span>
                  </div>
                  {p.text && <div className="ex-pool-item-text" style={{ color: subFg }}>{p.text}</div>}
                </div>
              </div>
            ))}
          </div>

          <div className="ex-pool-actions">
            <button className="ex-btn-primary" onClick={onCompose} style={{ background: '#e87aa3' }}>
              立即挑选合成
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Header ──────────────────────────────────────────────────────────────
function Header({ state, dark, fg, subFg, queueCount, poolCount, windowMin, windowProgress, onAbout, onPool, onToggleDark, interactive = true }) {
  const label = {
    [STATES.IDLE]:        'Expresser',
    [STATES.RECORDING]:   '正在听 · ASR 本地',
    [STATES.TRANSITION]:  '打开镜头…',
    [STATES.CAMERA]:      '相机',
    [STATES.CAPTURING]:   '正在拍摄',
    [STATES.RECORDING_V]: '录像中',
    [STATES.POOL]:        '已加入内容池',
    [STATES.COUNTDOWN]:   '即将自动发布',
    [STATES.COMPOSE]:     '挑选片段',
    [STATES.PROCESSING]:  '本地 AI 处理中',
    [STATES.UPLOADING]:   '同步至 NAS',
    [STATES.PUBLISHED]:   '已发布',
    [STATES.OFFLINE]:     '离线 · 已加入队列',
  }[state] || 'Expresser';
  const isIdle = state === STATES.IDLE && interactive;

  return (
    <div className="ex-header" style={{ color: fg }}>
      <button
        className="ex-brand ex-brand--btn"
        onClick={isIdle ? onAbout : undefined}
        style={{ color: fg, cursor: isIdle ? 'pointer' : 'default' }}
        aria-label="关于 Expresser">
        <Petal size={14} color={dark ? '#fff' : '#1d1c1a'} />
        <span style={{ fontWeight: 600, letterSpacing: '0.02em', fontSize: 15 }}>{label}</span>
      </button>
      <div className="ex-header-meta" style={{ color: subFg }}>
        {isIdle && (
          <button
            className="ex-pill ex-pill--soft ex-pill--btn"
            onClick={onPool}
            aria-label="打开内容池">
            <Petal size={9} color="#e87aa3" /> &nbsp;{poolCount} 片段{poolCount > 0 ? ` · ${Math.round(windowProgress * windowMin)}/${windowMin}min` : ''}
          </button>
        )}
        {state === STATES.OFFLINE && (
          <span className="ex-pill ex-pill--warn">QUEUE {queueCount}</span>
        )}
        {isIdle && (
          <button
            className="ex-theme-btn"
            onClick={onToggleDark}
            aria-label={dark ? '切换到浅色主题' : '切换到深色主题'}
            title={dark ? '浅色' : '深色'}>
            {dark ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="4" />
                <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z" />
              </svg>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

// tiny petal mark — real overlapping petal flower
function Petal({ size = 14, color = '#e87aa3' }) {
  const cx = size / 2, cy = size / 2;
  const len = size * 0.42, wid = size * 0.32;
  const N = 6;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {Array.from({ length: N }).map((_, i) => {
        const a = (i / N) * 360;
        return <path key={i} d={petalShapePath(cx, cy, len, wid, a)} fill={color} opacity="0.85" />;
      })}
      <circle cx={cx} cy={cy} r={size * 0.13} fill="#f5c454" />
    </svg>
  );
}

// ── Context text ────────────────────────────────────────────────────────
function ContextText({ state, fg, subFg, transcript, recSeconds, progress, publishedTo, ctd, poolCount, windowMin, onStartCountdown, onCancelCountdown }) {
  const fmt = (s) => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toFixed(0).padStart(2,'0')}`;

  if (state === STATES.IDLE) {
    return (
      <div className="ex-ctx ex-ctx--idle">
        <div className="ex-ctx-eyebrow">Hold &nbsp;·&nbsp; Record &nbsp;·&nbsp; Bloom</div>
        <h1 className="ex-ctx-title">片刻的表达,<em>生活的诗篇</em></h1>
        <div className="ex-ctx-sub" style={{ color: subFg }}>
          自动汇成 {windowMin} 分钟一篇 · 发前 5 秒可拦
        </div>
      </div>
    );
  }
  if (state === STATES.RECORDING) {
    return (
      <div className="ex-ctx ex-ctx--rec">
        <div className="ex-rec-meta">
          <span className="ex-rec-dot" />
          <span style={{ fontFamily: 'ui-monospace, SF Mono, Menlo, monospace', fontSize: 13 }}>REC &nbsp; {fmt(recSeconds)}</span>
          <span style={{ color: subFg, fontSize: 12, marginLeft: 8 }}>ASR · 本地</span>
        </div>
        <div className="ex-transcript">
          {transcript || <span style={{ color: subFg }}>开始说点什么…</span>}
          <span className="ex-cursor" />
        </div>
        <div className="ex-ctx-sub" style={{ color: subFg, marginTop: 18 }}>松手保存进内容池 · 上滑切到相机</div>
      </div>
    );
  }
  if (state === STATES.POOL) {
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow" style={{ color: '#3fbe6e' }}>+ ADDED</div>
        <h2 className="ex-ctx-title2">已存入今天的内容池</h2>
        <div style={{ color: subFg, fontSize: 13, marginTop: 4 }}>{poolCount} 个片段 · 满 {windowMin} 分钟时自动汇成草稿</div>
      </div>
    );
  }
  if (state === STATES.COUNTDOWN) {
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow" style={{ color: '#e87aa3' }}>AUTO-DRAFT READY</div>
        <h2 className="ex-ctx-title2">{ctd} 秒后自动发布</h2>
        <div style={{ color: subFg, fontSize: 13, marginTop: 6 }}>
          AI 已为你拼好今早的 {poolCount} 个片段 → 一篇图文 vlog
        </div>
        <button className="ex-ctx-btn" onClick={onCancelCountdown}>挑选片段 / 暂停</button>
      </div>
    );
  }
  if (state === STATES.PROCESSING || state === STATES.UPLOADING) {
    const isLocal = state === STATES.PROCESSING;
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow">{isLocal ? 'ON-DEVICE' : 'CLOUD · NAS @ home'}</div>
        <h2 className="ex-ctx-title2">{isLocal ? '本地拼版中' : '同步到家中 NAS'}</h2>
        <div className="ex-progress"><div className="ex-progress-bar" style={{ width: `${progress}%` }} /></div>
        <div className="ex-progress-meta" style={{ color: subFg }}>
          <span>{isLocal ? '提取要点 · 选封面 · 写草稿' : '剪辑 · 配字幕 · 排版'}</span>
          <span style={{ fontFamily: 'ui-monospace, SF Mono, Menlo, monospace' }}>{progress}%</span>
        </div>
      </div>
    );
  }
  if (state === STATES.PUBLISHED) {
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow" style={{ color: '#3fbe6e' }}>PUBLISHED</div>
        <h2 className="ex-ctx-title2">已发布到 {publishedTo.length} 个目标</h2>
        <div style={{ color: subFg, marginTop: 6, fontSize: 13 }}>预计阅读时长 2 分钟 ‧ 副本已存入 NAS</div>
      </div>
    );
  }
  if (state === STATES.OFFLINE) {
    return (
      <div className="ex-ctx">
        <div className="ex-ctx-eyebrow" style={{ color: '#e6a44b' }}>OFFLINE</div>
        <h2 className="ex-ctx-title2">先记着,联网后再发</h2>
      </div>
    );
  }
  return <div className="ex-ctx" />;
}

// ── PoolStrip — small horizontal strip showing recent pieces ────────────
function PoolStrip({ pool, dark, subFg, card }) {
  return (
    <div className="ex-pool-strip" style={{ animation: 'ex-fade-up 0.4s ease' }}>
      {pool.slice(-5).map(p => (
        <div key={p.id} className="ex-pool-chip" style={{ background: card }}>
          <PoolThumb piece={p} dark={dark} />
          <div style={{ fontSize: 10, color: subFg, marginTop: 4 }}>{p.t}</div>
        </div>
      ))}
    </div>
  );
}

function PoolThumb({ piece, dark }) {
  const grad = {
    warm: 'linear-gradient(135deg, #ffc59c, #e87aa3)',
    cool: 'linear-gradient(135deg, #b6c8ff, #8ba3d4)',
    mint: 'linear-gradient(135deg, #c0e6c8, #88c79d)',
  }[piece.cover || 'warm'];
  if (piece.kind === 'voice') {
    return (
      <div style={{
        width: 44, height: 44, borderRadius: 10,
        background: dark ? 'rgba(255,255,255,0.1)' : '#fff',
        border: dark ? 'none' : '1px solid rgba(0,0,0,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        gap: 2,
      }}>
        {[5, 10, 14, 8, 12, 6].map((h, i) => (
          <div key={i} style={{ width: 2, height: h, background: '#e87aa3', borderRadius: 1 }} />
        ))}
      </div>
    );
  }
  return (
    <div style={{
      width: 44, height: 44, borderRadius: 10, background: grad,
      position: 'relative', overflow: 'hidden',
    }}>
      {piece.kind === 'video' && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 14,
        }}>▶</div>
      )}
    </div>
  );
}

// ── Bottom — sticky pool/draft bar ──────────────────────────────────────
function BottomChrome({ state, dark, fg, subFg, publishedTo, poolCount, windowMin, windowProgress, onTapDraft, onCompose, card }) {
  // Show pool/draft bar when idle and pool has content; show targets when published
  if (state === STATES.PUBLISHED) {
    return (
      <div className="ex-bottom">
        <div className="ex-targets">
          {TARGETS.map(t => {
            const lit = publishedTo.includes(t.id);
            return (
              <div key={t.id} className={cls('ex-target', lit && 'ex-target--lit')}
                style={{
                  background: lit ? '#3fbe6e' : (dark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)'),
                  color: lit ? '#fff' : (dark ? '#f5f4ef' : '#1d1c1a'),
                }}>
                <TargetIcon id={t.id} />
                <div className="ex-target-text">
                  <div className="ex-target-label">{t.label}</div>
                  <div className="ex-target-sub" style={{ color: lit ? 'rgba(255,255,255,0.85)' : subFg }}>{t.sub}</div>
                </div>
                {lit && <div className="ex-target-tick">✓</div>}
              </div>
            );
          })}
        </div>
      </div>
    );
  }
  if (state === STATES.IDLE && poolCount > 0) {
    const pct = Math.round(windowProgress * 100);
    const remaining = Math.max(0, windowMin - Math.round(windowProgress * windowMin));
    return (
      <div className="ex-toast-wrap">
        <div className="ex-toast">
          <div className="ex-toast-row">
            <div className="ex-toast-icon">
              <Petal size={20} color="#e87aa3" />
            </div>
            <div className="ex-toast-body" onClick={onTapDraft} style={{ cursor: 'pointer' }}>
              <div className="ex-toast-title">今天的片刻正在汇集</div>
              <div className="ex-toast-sub">
                {poolCount} 片段 · 还差 {remaining} 分钟自动开成一篇
              </div>
            </div>
            <button className="ex-toast-cta" onClick={onCompose}>挑选</button>
          </div>
          <div className="ex-toast-track">
            <div className="ex-toast-fill" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </div>
    );
  }
  return null;
}

// ── Compose view — pick which pieces to combine ─────────────────────────
function ComposeView({ pool, selected, onToggle, onConfirm, onCancel, dark, color, subFg, card }) {
  const count = Object.values(selected).filter(Boolean).length;
  const hasVideo = pool.some(p => selected[p.id] && p.kind === 'video');
  return (
    <div className="ex-compose">
      <div className="ex-compose-head">
        <div className="ex-ctx-eyebrow" style={{ color: '#e87aa3' }}>COMPOSE</div>
        <h2 className="ex-ctx-title2" style={{ marginTop: 4 }}>挑选要合成的片段</h2>
        <div style={{ fontSize: 12, color: subFg, marginTop: 4 }}>
          已选 {count} 个 · {hasVideo ? '将合成 vlog (含字幕)' : '将合成图文 blog'}
        </div>
      </div>

      <div className="ex-compose-list">
        {pool.map(p => {
          const on = !!selected[p.id];
          return (
            <button key={p.id} className={cls('ex-piece', on && 'ex-piece--on')}
              onClick={() => onToggle(p.id)}
              style={{ background: on ? (dark ? 'rgba(232,122,163,0.18)' : 'rgba(232,122,163,0.12)') : card }}>
              <PoolThumb piece={p} dark={dark} />
              <div className="ex-piece-body">
                <div className="ex-piece-row1">
                  <span className="ex-piece-kind">
                    {p.kind === 'voice' ? '🔊 语音' : p.kind === 'photo' ? '📷 照片' : '🎬 视频'}
                  </span>
                  <span style={{ fontSize: 11, color: subFg, fontFamily: 'ui-monospace, monospace' }}>{p.t}</span>
                </div>
                <div className="ex-piece-text">
                  {p.text || (p.kind === 'photo' ? `${p.tag} · 1 张` : `${p.tag} · ${p.dur}`)}
                </div>
              </div>
              <div className={cls('ex-piece-tick', on && 'ex-piece-tick--on')}>
                {on && '✓'}
              </div>
            </button>
          );
        })}
      </div>

      <div className="ex-compose-actions">
        <button className="ex-btn-ghost" onClick={onCancel}>暂停 · 继续追加</button>
        <button className="ex-btn-primary" onClick={onConfirm} disabled={count === 0}
          style={{ background: count > 0 ? color : '#bbb' }}>
          合成并发布 ({count})
        </button>
      </div>
    </div>
  );
}

// ── Camera viewfinder ──────────────────────────────────────────────────
function CameraViewfinder({ state, dark, color, mode, onModeChange, onShutterTap, onShutterHold, onClose, recSeconds }) {
  const isVid = state === STATES.RECORDING_V;
  const trans = state === STATES.TRANSITION;
  const [holdTimer, setHoldTimer] = React.useState(null);
  const onShutterDown = () => { const t = setTimeout(() => onShutterHold(), 320); setHoldTimer(t); };
  const onShutterUp = () => { if (holdTimer) { clearTimeout(holdTimer); setHoldTimer(null); if (state === STATES.CAMERA) onShutterTap(); } };
  return (
    <div className={cls('ex-cam', trans && 'ex-cam--in')}>
      <div className="ex-cam-scene">
        <div className="ex-cam-scene-grad" />
        <div className="ex-cam-scene-blob ex-cam-blob-1" />
        <div className="ex-cam-scene-blob ex-cam-blob-2" />
        <div className="ex-cam-scene-blob ex-cam-blob-3" />
        <div className="ex-cam-grid"><div /><div /><div /><div /></div>
        <div className="ex-cam-focus" />
        <div className="ex-cam-placeholder">PREVIEW · {mode.toUpperCase()}</div>
      </div>
      <button className="ex-cam-close" onClick={onClose}>✕</button>
      <div className="ex-cam-mode-top">
        {isVid ? (<><span className="ex-rec-dot" /><span style={{ fontFamily: 'ui-monospace, monospace' }}>REC {recSeconds.toFixed(1)}s</span></>)
               : (<span style={{ fontFamily: 'ui-monospace, monospace' }}>● {mode.toUpperCase()}</span>)}
      </div>
      {!isVid && (
        <div className="ex-cam-modes">
          {CAM_MODES.map(m => (
            <button key={m.id} className={cls('ex-cam-mode', mode === m.id && 'ex-cam-mode--on')}
              onClick={() => onModeChange(m.id)}>
              <div className="ex-cam-mode-label">{m.label}</div>
              <div className="ex-cam-mode-sub">{m.sub}</div>
            </button>
          ))}
        </div>
      )}
      <button className={cls('ex-cam-shutter', isVid && 'ex-cam-shutter--rec')}
        onPointerDown={onShutterDown} onPointerUp={onShutterUp} onPointerLeave={onShutterUp}>
        <div className="ex-cam-shutter-inner" />
      </button>
      {!isVid && <div className="ex-cam-hint">点击拍照 · 长按录像 · 都进内容池</div>}
    </div>
  );
}

// icons
function Icon({ kind }) {
  if (kind === 'tap') return (<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="3" fill="currentColor" /><circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1" opacity="0.5" /></svg>);
  if (kind === 'up') return (<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M8 12 V4 M5 7 L8 4 L11 7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
  if (kind === 'left') return (<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 8 H12 M7 5 L4 8 L7 11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
  if (kind === 'right') return (<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 8 H12 M9 5 L12 8 L9 11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>);
  return null;
}
function TargetIcon({ id }) {
  if (id === 'blog') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M5 3 H15 L19 7 V21 H5 Z"/><path d="M9 11 H15 M9 15 H13"/></svg>;
  if (id === 'feed') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1.5" fill="currentColor"/><path d="M4 16 L9 12 L13 15 L17 11 L20 14"/></svg>;
  if (id === 'reels') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M10 10 L14 12.5 L10 15 Z" fill="currentColor"/></svg>;
  if (id === 'nas') return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="5" width="18" height="5" rx="1"/><rect x="3" y="14" width="18" height="5" rx="1"/></svg>;
  return null;
}

window.ExpresserApp = ExpresserApp;
window.STATES = STATES;
